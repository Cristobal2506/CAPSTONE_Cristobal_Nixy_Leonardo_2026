# Rumbo SIMCE v13.1 — Manual completo de instalación, compilación y pruebas

**Manual de entrega para el equipo del proyecto de título**  
**Fecha:** 24 de octubre de 2026 · **Sistema principal:** Windows 10/11 de 64 bits · **Destino:** Android · **Modalidad:** demostración académica.  
**Objetivo:** preparar una única APK Android que incluya la práctica de Matemática de 4° básico, diagnóstico de entrada, cinco pruebas de unidad con dictamen docente, ensayo final y videoconferencia LiveKit; todo desde un computador Windows sin herramientas previas.

> **Estado de validación:** la base de videoconferencias LiveKit fue compilada y probada satisfactoriamente por el equipo en **dos teléfonos Android**. La v13 tuvo una compilación funcional confirmada por el usuario; los cambios específicos de la v13.1 (nuevo diagnóstico, campanita y menú de ajustes) aún requieren una nueva compilación y comprobación en dispositivos. La validación estructural realizada aquí no garantiza automáticamente su funcionamiento en otros PC.

> **Precisión curricular:** el PDF entregado como temario es de **exámenes de validación de estudios para menores** (Mineduc/UCE, 4° básico), no el temario ni una prueba oficial SIMCE. Aquí se utiliza su sección de Matemática (14 OA) como referencia curricular. El ensayo final de 40 preguntas es **una simulación original** orientada por los cinco ejes matemáticos y datos técnicos publicados por la Agencia de Calidad. Ninguna pregunta es un ítem oficial SIMCE. Los cuadernillos Kumon se utilizaron como referencia de progresión; no se reprodujeron sus páginas.

> **Regla de seguridad:** nunca subas a GitHub los archivos `.env`, las claves de LiveKit, contraseñas ni capturas con tokens. Todas las credenciales mostradas aquí son *marcadores de ejemplo* y deben reemplazarse donde se indique.

## 1. Qué vas a instalar y por qué

| Componente | Función | ¿Se ejecuta durante la demo? |
|---|---|---|
| Node.js 22 LTS + npm | Ejecutar el backend, Expo y herramientas JavaScript | Sí |
| Git (recomendado) | Descargar el proyecto y gestionar versiones | No es imprescindible para ejecutar un ZIP |
| Docker Desktop + WSL 2 | Crear PostgreSQL en un contenedor | Sí |
| Android Studio y Android SDK | Generar y compilar la aplicación Android | Para compilar; puede cerrarse después |
| JDK 21 | Máquina virtual Java compatible para Gradle | Para compilar |
| LiveKit Cloud (cuenta gratuita) | Servidor de señalización y transporte multimedia | Sí, requiere Internet |
| Banco curricular (en PostgreSQL) | 5 unidades, 17 tandas, diagnóstico, pruebas y ensayo original | Sí |
| Dos teléfonos Android | Pruebas de estudiante y docente | Sí |
| Visual Studio Code (opcional) | Editar `.env` y consultar archivos | No |

**Arquitectura:** teléfonos Android  y  backend Express en el PC  y  PostgreSQL en Docker. Para audio y video, ambos teléfonos se conectan por Internet a LiveKit Cloud mediante los tokens emitidos por el backend. La **misma APK** contiene las pantallas educativas y la sala de videollamada. La compilación de desarrollo necesita además un servidor **Metro** activo en el PC.

### 1.1 Convenciones para no confundir rutas

Para explicar los comandos usaremos una carpeta corta **de ejemplo**:

```text
C:\Rumbo\v131\rumbo-simce\
   backend\
   mobile\
   docs\
   docker-compose.yml
```

Puedes escoger cualquier otra ruta de tu computador. Cuando veas `C:\Rumbo\v131\rumbo-simce`, **reemplázala por la ruta donde descomprimiste el proyecto**; no significa que esa carpeta exista de antemano. No uses el usuario, las direcciones IP ni las rutas de otro integrante del equipo.

Los comandos se escriben en **PowerShell** (no en la consola de Node). Abre una terminal nueva tras instalar un programa o editar variables del sistema para que Windows recargue el entorno.

## 2. Primeros pasos en Windows

### 2.1 Comprobar Windows y conexión

1. Presiona **Win + I → Sistema → Acerca de** y comprueba que Windows sea de **64 bits**.
2. Asegúrate de tener conexión a Internet, permisos para instalar aplicaciones y espacio libre suficiente (Android SDK/Gradle/Docker pueden ocupar varios GB).
3. En Windows 10, activa la virtualización en BIOS/UEFI si Docker indica que no está disponible; el procedimiento depende del fabricante.
4. Abre PowerShell desde Inicio. Para instalaciones del sistema es posible que se requiera **Ejecutar como administrador**; para usar Git/npm y ejecutar el proyecto, utiliza una ventana normal.

### 2.2 Instalar Git (recomendado)

Descarga **Git for Windows** desde `https://git-scm.com/download/win`; utiliza las opciones estándar del instalador, incluida la integración de Git con la línea de comandos. Cierra y abre PowerShell:

```powershell
git --version
```

Para instalar desde un ZIP no necesitas clonar GitHub; este paso es útil para recibir actualizaciones y publicar cambios.

### 2.3 Instalar Node.js 22 LTS

1. Entra a `https://nodejs.org/` y busca una distribución **Node.js 22 LTS** para Windows x64. Si el sitio recomienda actualmente otra versión, utiliza explícitamente Node 22 para reproducir este proyecto.
2. Ejecuta el instalador `.msi`, conserva la opción de añadir Node al **PATH** y finaliza.
3. Abre una **nueva** PowerShell y comprueba:

```powershell
node -v
npm -v
where.exe node
```

La primera línea debe empezar por `v22.`. `where.exe node` muestra la ruta del ejecutable realmente usado. Si Windows no reconoce `node`, reinicia PowerShell; verifica en **Configuración → Sistema → Acerca de → Configuración avanzada del sistema → Variables de entorno** que la ruta de instalación, habitualmente `C:\Program Files\nodejs\`, aparezca en `Path`.

### 2.4 Instalar Java JDK 21 (paso obligatorio)

**No confundas el JDK con el JRE.** Gradle necesita un kit de desarrollo Java **JDK 21**. Una versión superior que Android Studio traiga por defecto no reemplaza este requisito.

1. Abre `https://adoptium.net/temurin/releases/?version=21`.
2. Selecciona **Windows**, **x64**, **JDK** y versión **21 (LTS)**. Descarga el instalador `.msi` de Eclipse Temurin.
3. Durante la instalación, activa las opciones para **establecer JAVA_HOME** y **añadir Java al PATH**, cuando estén disponibles.
4. Al finalizar, localiza el directorio instalado; normalmente tendrá una forma como `C:\Program Files\Eclipse Adoptium\jdk-21.0.xx.x-hotspot`. **El nombre exacto dependerá de la actualización descargada.**
5. Abre PowerShell nueva y ejecuta:

```powershell
java -version
javac -version
$env:JAVA_HOME
where.exe java
```

Los resultados `java` y `javac` deben indicar **21**. `$env:JAVA_HOME` debe apuntar a la carpeta principal del JDK (la que contiene `bin`, no a `bin` mismo).

**Si no quedó configurado automáticamente:**

1. En Inicio escribe **Editar las variables de entorno del sistema** y abre el resultado.
2. Presiona **Variables de entorno…**.
3. Bajo **Variables de usuario**, pulsa **Nueva…**, escribe nombre `JAVA_HOME` y como valor la **ruta real del JDK 21**, por ejemplo `C:\Program Files\Eclipse Adoptium\jdk-21.0.xx.x-hotspot`. No copies literalmente `xx`.
4. Selecciona `Path` en Variables de usuario → **Editar…** → **Nuevo** → escribe `%JAVA_HOME%\bin`.
5. Si existe una entrada que antepone Java 25 o algún Java antiguo, mueve `%JAVA_HOME%\bin` por encima de esas rutas, o corrige la entrada conflictiva con cuidado.
6. Acepta todos los cuadros, **cierra y vuelve a abrir PowerShell**. Repite las comprobaciones.

**Para utilizar Java 21 solamente en una terminal**, sin cambiar otras aplicaciones de Windows, también puedes hacer:

```powershell
$env:JAVA_HOME = 'C:\RUTA_REAL_DEL_JDK_21'
$env:Path = "$env:JAVA_HOME\bin;$env:Path"
java -version
```

Sustituye `C:\RUTA_REAL_DEL_JDK_21` por tu directorio exacto. No incluyas comillas como parte del valor de `JAVA_HOME`.

### 2.5 Instalar Docker Desktop y WSL 2

1. Si WSL 2 aún no está disponible, abre PowerShell **como administrador** y ejecuta:

```powershell
wsl --install
```

2. Reinicia Windows cuando se solicite. Si tu empresa o universidad bloquea WSL, tendrás que pedir permisos o utilizar una instalación local de PostgreSQL adaptando la configuración; el recorrido de este manual se basa en Docker.
3. Descarga Docker Desktop desde `https://www.docker.com/products/docker-desktop/` e instálalo con el motor basado en **WSL 2**.
4. Abre Docker Desktop, acepta la configuración inicial y espera a que el motor indique que está funcionando.
5. Comprueba en una nueva PowerShell:

```powershell
wsl --status
docker --version
docker compose version
docker info
```

`docker info` debe conectarse al motor; si aparece un error sobre el **Docker daemon**, revisa que Docker Desktop esté iniciado y que la virtualización/WSL 2 funcionen.

### 2.6 Instalar Android Studio, SDK, ADB y CMake

1. Descarga Android Studio desde `https://developer.android.com/studio`.
2. Ejecuta el instalador e incluye **Android SDK** y sus componentes básicos. Completa el asistente de primer inicio y acepta las licencias.
3. En Android Studio abre **More Actions → SDK Manager**, o **File → Settings → Languages & Frameworks → Android SDK**.
4. En **SDK Platforms** instala **Android API 36** (plataforma usada por la configuración actual del proyecto).
5. En **SDK Tools**, activa **Android SDK Platform-Tools**, **Android SDK Build-Tools**, **Android SDK Command-line Tools**, **NDK (Side by side)** y **CMake** si aparecen como componentes necesarios. Puede que Gradle descargue una versión específica de NDK/CMake en la primera compilación; acepta la instalación.
6. Anota el campo **Android SDK Location** (por ejemplo `C:\Users\TU_USUARIO\AppData\Local\Android\Sdk`). Esa es tu ruta real: no copies la de otra persona.

**Crear las variables para Android:** abre **Variables de entorno** como en el apartado de Java. Dentro de Variables de usuario crea `ANDROID_HOME` cuyo valor sea **la ruta real de Android SDK**. Luego edita `Path` y añade:

```text
%ANDROID_HOME%\platform-tools
%ANDROID_HOME%\cmdline-tools\latest\bin
```

La segunda ruta es opcional para este flujo y solo existe si instalaste Command-line Tools. No incluyas `bin` dentro de `ANDROID_HOME`.

Abre PowerShell nueva y ejecuta:

```powershell
$env:ANDROID_HOME
adb version
where.exe adb
```

Si `adb` no aparece, prueba temporalmente:

```powershell
$env:Path = "$env:ANDROID_HOME\platform-tools;$env:Path"
adb version
```

En Android Studio abre **Settings → Build, Execution, Deployment → Build Tools → Gradle**. En **Gradle JDK**, selecciona **JDK 21** (la instalación Temurin 21 anterior o un JBR 21 disponible). Si solo aparece JBR 25, usa **Add JDK… / Download JDK… / Browse…** según la versión de Android Studio, y señala la carpeta del JDK 21 que instalaste. La selección se revisará de nuevo antes de compilar.

## 3. Extraer el proyecto y comprobar la estructura

1. Descarga el archivo ZIP de distribución de Rumbo SIMCE v13.1.
2. En el Explorador de archivos, haz clic derecho → **Extraer todo…** y usa una ruta CORTA, preferentemente `C:\Rumbo\v131`. **No extraigas en Escritorio\Universidad\Capstone\Versiones\...**: las rutas largas provocan un fallo de Ninja/CMake (`Filename longer than 260 characters`).
3. Comprueba que en la carpeta extraída estén `backend`, `mobile`, `docs` y `docker-compose.yml` bajo `rumbo-simce`.
4. En PowerShell:

```powershell
cd 'C:\Rumbo\v131\rumbo-simce'
Get-ChildItem
```

Si `docker-compose.yml` no está en esa carpeta, **no continúes con comandos de instalación**: revisa dónde quedó la carpeta `rumbo-simce`. La forma más fiable de obtener la ruta es abrir esa carpeta en el Explorador, hacer clic en la barra de direcciones y copiarla.

No es necesario que exista `mobile\android` todavía: esa carpeta se generará con Expo Prebuild. No copies `node_modules` de otro PC.

## 4. Crear LiveKit Cloud y obtener credenciales gratuitas

1. Abre `https://cloud.livekit.io/` y regístrate.
2. Selecciona el plan gratuito disponible para desarrollo (denominado **Build** cuando se preparó este manual). **Revisa los límites y condiciones actuales en la consola**, ya que pueden cambiar.
3. Crea un proyecto, por ejemplo `rumbo-simce-demo`.
4. Abre la sección del proyecto correspondiente a **API Keys / Settings / Keys** (los nombres exactos pueden variar con la interfaz).
5. Crea o consulta las credenciales y guarda, en un lugar privado, los tres datos: **URL del proyecto**, **API Key** y **API Secret**.

Ejemplos de formato, **no credenciales reales**:

```dotenv
LIVEKIT_URL=wss://ejemplo-abc123.livekit.cloud
LIVEKIT_API_KEY=REEMPLAZAR_CON_CLAVE_REAL
LIVEKIT_API_SECRET=REEMPLAZAR_CON_SECRETO_REAL
```

La URL empieza con `wss://`, no con `http://`. El backend firma el token de cada participante: **solo el backend puede conocer el API Secret**. Los teléfonos necesitan Internet para acceder a LiveKit Cloud. No necesitas instalar LiveKit en Windows.

## 5. Identificar la IP del computador y preparar la red

1. Conecta el PC y ambos teléfonos a la **misma red Wi-Fi**, sin aislamiento de clientes. Si el PC está por Ethernet, debe estar en una red local que permita conexiones desde los móviles.
2. Abre PowerShell:

```powershell
ipconfig
```

3. Encuentra el adaptador realmente conectado: **Adaptador de LAN inalámbrica Wi-Fi** o **Ethernet**. Busca la línea **Dirección IPv4**. Anota la dirección, por ejemplo `192.168.1.37`.
4. **Esa dirección es solamente un ejemplo.** Cada compañero debe consultar su propia IP. No uses la IP de un compañero ni `localhost` en la app del teléfono.
5. Para comprobar cambios de IP más adelante, vuelve a ejecutar `ipconfig`. La IP puede variar al conectarse a otra red o reiniciar el router.

Si Windows muestra una pregunta de firewall al iniciar Node.js o Metro, permite acceso en **redes privadas de confianza**. No es necesario exponer los puertos del backend a Internet; solo deben ser accesibles desde la red local de la demostración.

## 6. Iniciar PostgreSQL con Docker — Terminal A

Abre Docker Desktop y comprueba que el motor está activo. Abre PowerShell:

```powershell
cd 'C:\Rumbo\v131\rumbo-simce'
docker compose up -d
docker compose ps
```

El archivo `docker-compose.yml` incluido crea PostgreSQL 16, una base `rumbo_simce` y el usuario local de demostración `rumbo`. El puerto **5433 del computador** se conecta al puerto **5432 del contenedor**. Esto evita colisiones con otras instalaciones de PostgreSQL.

Para comprobar el servidor de base de datos:

```powershell
docker compose exec db pg_isready -U rumbo -d rumbo_simce
```

Debe indicar que acepta conexiones. Si el puerto 5433 ya está en uso, identifica la aplicación con `netstat -ano | findstr :5433`; no cambies el puerto sin actualizar también `DATABASE_URL` y `TEST_DATABASE_URL`.

**No ejecutes `docker compose down -v`** salvo que quieras borrar permanentemente la base y su volumen. `docker compose stop` detiene el contenedor sin eliminar datos.

## 7. Configurar e iniciar el backend — Terminal B

Abre **otra** PowerShell y sitúate en `backend`:

```powershell
cd 'C:\Rumbo\v131\rumbo-simce\backend'
Copy-Item .env.example .env
notepad .env
```

En Bloc de notas configura los valores siguientes, manteniendo el resto de variables del ejemplo. Reemplaza los marcadores por tus datos **reales**:

```dotenv
PORT=3000
DATABASE_URL=postgres://rumbo:rumbo@localhost:5433/rumbo_simce
TEST_DATABASE_URL=postgres://rumbo:rumbo@localhost:5433/rumbo_simce_test
JWT_SECRET=REEMPLAZAR_POR_UN_TEXTO_ALEATORIO_LARGO_Y_PRIVADO
KUMON_MAX_INTENTOS_SIN_ESTANDAR=3
KUMON_CIERRE_NIVEL_CON_PROFESOR=true
LIVEKIT_URL=wss://TU_PROYECTO_REAL.livekit.cloud
LIVEKIT_API_KEY=TU_API_KEY_REAL
LIVEKIT_API_SECRET=TU_API_SECRET_REAL
```

**Generar un `JWT_SECRET` de demostración** sin escribir un valor predecible:

```powershell
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Copia la cadena generada a `JWT_SECRET`; esta clave del sistema de login **no es** el API Secret de LiveKit. Guarda el `.env` y cierra el editor.

Instala los paquetes y prepara el banco curricular de Matemática con datos de demostración. **`db:reset` borra la base de datos configurada** y solo se usa cuando está recién creada y destinada a pruebas:

```powershell
npm install
npm run db:reset
npm run db:demo
npm run verificar:v13.1
npm run dev
```

**Actualización desde una instalación anterior (sin perder datos):** realiza una copia de seguridad de PostgreSQL y ejecuta **`npm run db:seed`**. La migración `011_diagnostico_v131.sql` crea un diagnóstico nuevo y conserva la prueba anterior para quienes ya la iniciaron; la migración `012_avisos_apoderado_v131.sql` habilita notificaciones para apoderados. La semilla `007_diagnostico_unico_v131.sql` carga los nuevos reactivos. Si usas una base de demostración descartable por primera vez, `db:reset` configura todo desde cero. El cambio de cuestionario no modifica intentos antiguos ni notas históricas.

**Atención:** `npm run db:reset` borra datos de la base configurada. Debe usarse solo cuando la base sea nueva y exclusivamente de demostración. Para conservar una base existente, respáldala previamente; después utiliza **`npm run db:seed`**, que aplica migraciones y vuelve a cargar los archivos de contenido de manera idempotente. Las migraciones y semillas preparan el currículo y ajustan los estudiantes ya registrados sin requerir un reinicio destructivo. No uses `db:reset` si quieres preservar estudiantes o intentos.

Con la API activa, abre desde el **mismo PC** `http://localhost:3000/api/health`. Debería responder con `{"ok":true}`. Después, en el navegador de **cada teléfono**, abre `http://IP_REAL_DEL_PC:3000/api/health`, sustituyendo la dirección por la del apartado 5. Ambos teléfonos deben recibir respuesta **antes** de avanzar.

Si el PC funciona pero los teléfonos no, revisa firewall de Windows, la IP actual, aislamiento Wi-Fi y que el proceso del backend siga activo. Para ver qué proceso ocupa el puerto: `netstat -ano | findstr :3000`.

**Cuentas ficticias incluidas por el script de demostración:**

| Perfil | Usuario / código | Clave |
|---|---|---|
| Alumno | `RUMB24` | PIN `1234` |
| Docente | `docente@demo.cl` | `demo1234` |
| Apoderado | `apoderado@demo.cl` | `demo1234` |
| Administrador | `admin@demo.cl` | `demo1234` |

El curso de demostración se identifica como `CURS4A`. Estas credenciales son solo para un proyecto académico con datos ficticios.

## 8. Preparar Expo y la configuración móvil — Terminal C

Abre una tercera PowerShell:

```powershell
cd 'C:\Rumbo\v131\rumbo-simce\mobile'
Copy-Item .env.example .env
notepad .env
```

El archivo móvil utiliza **la IP de tu computador**, no la URL de LiveKit ni la dirección de otro compañero. Ejemplo **ficticio**: si `ipconfig` muestra `192.168.1.37`, escribe:

```dotenv
EXPO_PUBLIC_API_URL=http://192.168.1.37:3000/api
```

Reemplaza `192.168.1.37` por tu IP verdadera. No coloques `localhost`, `127.0.0.1`, claves de LiveKit ni contraseñas en `mobile/.env`. Las variables con prefijo `EXPO_PUBLIC_` pueden quedar visibles en el código JavaScript distribuido, por eso solo contienen la URL pública de la API de desarrollo.

Guarda y ejecuta:

```powershell
npm install
npm run verificar:v13.1
npx --no-install expo install --check
npm run typecheck
```

La dependencia `react-native-safe-area-context` está fijada en `~5.7.0`, que fue la versión compatible solicitada por Expo SDK 57 durante la instalación anterior. Si Expo detecta diferencias menores, **lee qué paquetes cambiará** antes de aceptarlas; no actualices manualmente a otra versión mayor de Expo o React Native. La primera instalación de npm puede tardar varios minutos y requiere Internet. El código fuente no incorpora `node_modules` ni artefactos Android. `npm install` descargará las dependencias y generará `mobile/package-lock.json` en cada equipo.

**Importante:** este proyecto utiliza React Native WebRTC y requiere compilación nativa; **no puede ejecutarse dentro de Expo Go**. Se construye una APK de desarrollo que incluye las bibliotecas correspondientes.

## 9. Generar proyecto Android con Java 21 — Terminal C

En la misma ventana de PowerShell, comprueba:

```powershell
java -version
$env:JAVA_HOME
```

Si la versión visible **no** es 21, establece temporalmente el JDK 21 con la ruta real que encontraste en el apartado 2.4:

```powershell
$env:JAVA_HOME = 'C:\RUTA_REAL_DEL_JDK_21'
$env:Path = "$env:JAVA_HOME\bin;$env:Path"
java -version
```

**No copies literalmente `C:\RUTA_REAL_DEL_JDK_21`.** Luego ejecuta:

```powershell
npm run prebuild:android
```

Este comando genera `mobile\android` desde la configuración Expo **y aplica automáticamente** `toolchainVersion=21` en el archivo `android\gradle\gradle-daemon-jvm.properties`. Comprueba:

```powershell
Get-Content .\android\gradle\gradle-daemon-jvm.properties
```

Debe contener `toolchainVersion=21`. Si vuelves a generar `android` manualmente, ejecuta después `npm run preparar:android:v13.1` desde la carpeta `mobile`. No cambies el Gradle Wrapper, el NDK o las versiones de Java al azar.

## 10. Compilar la APK de Android — Terminal D

Puedes usar Android Studio o PowerShell. Para una primera compilación, abre Android Studio → **File → Open** → elige **la carpeta `mobile\android`**, no `mobile` ni `backend`. Comprueba **Gradle JDK = 21**, acepta la sincronización y cualquier licencia o SDK faltante. Después selecciona **Build → Build APK(s)** (el texto exacto puede cambiar según Android Studio).

**Alternativa reproducible mediante PowerShell:**

```powershell
cd 'C:\Rumbo\v131\rumbo-simce\mobile\android'
.\gradlew.bat --stop
.\gradlew.bat --version
```

Si la salida muestra *Launcher JVM* o *Daemon JVM* usando Java 25, no continúes: revisa los apartados 2.4, 2.6 y 9, cierra terminales antiguas y comprueba nuevamente. Cuando ambas JVM utilicen Java 21:

```powershell
.\gradlew.bat :app:assembleDebug --stacktrace
```

Es normal que la primera compilación descargue componentes y tarde varios minutos. El resultado correcto es `BUILD SUCCESSFUL`. El archivo generado estará en:

```text
C:\Rumbo\v131\rumbo-simce\mobile\android\app\build\outputs\apk\debug\app-debug.apk
```

Si usaste otra ruta para extraer el proyecto, el APK estará en esa **misma ruta relativa** dentro de `mobile\android\app\build\outputs\apk\debug`.

**Qué acabas de construir:** una sola **APK de desarrollo**. Es una aplicación Android real, pero para cargar las pantallas JavaScript debe conectarse al servidor Metro; **no es un APK release autónomo**. No prometas que pueda instalarse y ejecutarse lejos del computador sin Metro.

## 11. Instalar la misma APK en los dos teléfonos

**Método sencillo:** copia `app-debug.apk` a ambos teléfonos mediante USB o un medio de transferencia, ábrelo desde Archivos y autoriza la instalación desde esa fuente si Android lo solicita. Solo se instala **Rumbo SIMCE**.

**Método USB con ADB:** en cada teléfono abre Ajustes → Información/Acerca del teléfono → pulsa siete veces **Número de compilación** (según fabricante) para habilitar las Opciones de desarrollador. Activa **Depuración USB**, conecta el cable de datos y acepta la autorización en pantalla. Desde `mobile\android`:

```powershell
adb devices
adb install -r .\app\build\outputs\apk\debug\app-debug.apk
```

Si sale `unauthorized`, desbloquea el teléfono y acepta el diálogo. Si falla una actualización por firmas incompatibles, desinstala la instalación anterior sabiendo que perderás sus datos locales y vuelve a instalar.

**Permisos:** al entrar en videollamada concede **cámara** y **micrófono**. Si fueron rechazados, ajusta los permisos de la aplicación desde Ajustes del teléfono.

## 12. Iniciar Metro y abrir la app — Terminal E

Asegúrate de que Docker/PostgreSQL siga encendido y de que el backend continúe ejecutándose en su ventana. Abre una nueva PowerShell:

```powershell
cd 'C:\Rumbo\v131\rumbo-simce\mobile'
$env:REACT_NATIVE_PACKAGER_HOSTNAME = 'IP_REAL_DEL_PC'
npx --no-install expo start --dev-client --host lan -c
```

**Sustituye** `IP_REAL_DEL_PC` (incluidas las comillas, pero conservando la IP entre ellas) por la dirección obtenida con `ipconfig`, por ejemplo:

```powershell
$env:REACT_NATIVE_PACKAGER_HOSTNAME = '192.168.1.37'
```

El comando de arranque de Expo debe ejecutarse **después** de establecer esa variable. Se abrirá Metro y aparecerá una dirección y un código QR. Los teléfonos tienen que estar en la misma red local y poder llegar al PC. Abre la APK **Rumbo SIMCE**; si muestra el lanzador de desarrollo, selecciona el servidor detectado o conecta utilizando la URL/QR que muestre Metro. No uses Expo Go.

**Durante las pruebas deben seguir activos:** Docker con PostgreSQL, backend Express y Metro. LiveKit Cloud requiere Internet en los teléfonos. Android Studio puede permanecer cerrado.

---

## 13. Qué contiene y cómo se evalúa

### 13.1 Currículo por unidades

La aplicación contiene cinco unidades para Matemática de cuarto básico, basadas en 14 objetivos de aprendizaje del temario de validación de estudios entregado por Mineduc. El contenido constituye **práctica y simulación originales** y no representa preguntas oficiales SIMCE ni páginas licenciadas de Kumon.

| Unidad | Temas | OA |
|---|---|---|
| 1 | Números hasta 10.000, valor posicional, adición y sustracción | OA1 y OA3 |
| 2 | Multiplicación, división y problemas con dinero | OA5, OA6 y OA7 |
| 3 | Fracciones y operaciones con igual denominador | OA8 y OA9 |
| 4 | Patrones, ecuaciones e inecuaciones de un paso | OA13 y OA14 |
| 5 | Simetría, transformaciones, medición, áreas y gráficos | OA17, OA18, OA22, OA23 y OA27 |

En cada unidad el alumno practica en conjuntos de dos hojas, con ejemplo resuelto y ejercicios de dificultad progresiva. Hay 17 conjuntos activos y 170 preguntas de práctica. El cumplimiento del estándar de la tanda sigue siendo individualizado (correctas a la primera y tiempo configurable en el panel administrador).

### 13.2 Esquema de evaluaciones

| Prueba | Preguntas | Duración | Quién determina el avance |
|---|---:|---:|---|
| Diagnóstico inicial | 40 | 60 min | Profesor asigna Unidad 1, 2, 3, 4 o 5 |
| Prueba final de cada una de las 5 unidades | 25 | 50 min | Profesor aprueba o reprueba y comenta |
| Ensayo integrador original | 40 | Configurada en el catálogo | Profesor revisa y comenta |

Las pruebas guardan cada selección en PostgreSQL. **El reloj es efectivo, no orientativo**: transcurrido el límite, el servidor impide nuevas respuestas y permite enviar las que existan, incluso si quedaron incompletas. Al reabrir una prueba en curso, se conserva la hora original de inicio. Las respuestas y los puntajes se calculan en el servidor; el alumno no los recibe durante la revisión.

**Notificaciones:** se almacenan en PostgreSQL y se consultan desde la **campanita de la esquina superior derecha** en las cuentas de alumno, docente y apoderado. Un círculo rojo muestra el número de avisos no leídos (hasta «99+») y se actualiza aproximadamente cada 15 segundos. El apoderado vinculado recibe un aviso al revisarse una prueba del alumno. Los mensajes son internos y **no son notificaciones push** de Android: no aparecen si la app está cerrada.

## 14. Pruebas de aceptación paso a paso

Realiza las siguientes comprobaciones con el backend, Docker, Metro y LiveKit Cloud encendidos. Se recomienda un teléfono para un alumno y otro para el profesor. Después de `npm run db:reset` y `npm run db:demo` se crean cuentas **ficticias**:

| Rol | Usuario | Contraseña / PIN |
|---|---|---|
| Alumno | `RUMB24` | `1234` |
| Docente | `docente@demo.cl` | `demo1234` |
| Apoderado | `apoderado@demo.cl` | `demo1234` |
| Admin | `admin@demo.cl` | `demo1234` |

El estudiante ficticio está vinculado al curso del profesor. Para crear otros alumnos, inicia sesión como apoderado y acepta el consentimiento, crea un alumno y vincúlalo al curso de un docente mediante su código. **El diagnóstico requiere que el alumno tenga profesor asignado antes de comenzar.**

### 14.1 Comprobaciones básicas

1. Comprueba que `docker compose ps` indica base activa.
2. Desde el PC abre `http://localhost:3000/api/health`.
3. Desde ambos teléfonos abre `http://IP_REAL_PC:3000/api/health`, sustituyendo `IP_REAL_PC` por tu IPv4.
4. Comprueba que Metro muestra un servidor disponible y carga la APK en cada teléfono, sin usar Expo Go.
5. Inicia sesión como alumno y como profesor en teléfonos separados. Comprueba la campanita en la esquina superior derecha de ambos perfiles.
6. Comprueba que ningún alumno ve el panel de docente y viceversa; repite con apoderado para comprobar su campanita.

### 14.2 Diagnóstico inicial obligatorio: 40 preguntas / 60 minutos

1. En el teléfono del alumno con la cuenta de demostración recién creada, debe aparecer automáticamente **Tu punto de partida**, antes del camino de unidades.
2. Comprueba que **Mi camino** y las tandas están cerrados mientras no exista una asignación docente.
3. Pulsa **Comenzar diagnóstico**. Debes ver exactamente 40 preguntas y reloj con 60 minutos.
4. Responde algunas preguntas. Pulsa **⚙ Ajustes**, arriba a la derecha junto a 🔔. Confirma **Salir del examen**; no debe existir un botón «Salir» permanente en el pie de pantalla. Abre nuevamente: deben conservarse las respuestas y continuar el tiempo original.
5. Completa las 40 preguntas y elige **Entregar examen**. Solo debe aparecer un mensaje de descanso y espera, **sin cantidad de aciertos ni porcentaje**.
6. Intenta iniciar nuevamente el diagnóstico: el sistema debe impedir un nuevo intento.
7. El docente entra a **Pruebas a revisar** y encuentra el nombre/apodo, 40 preguntas, nota calculada y duración.
8. Sin comentario escrito, **no** debe permitir enviar la revisión.
9. Selecciona como unidad inicial, por ejemplo, **Unidad 3**, escribe un comentario y pulsa **Asignar unidad y habilitar camino**.
10. El alumno abre la **campanita 🔔 de la cabecera**, recibe el comentario, y la pantalla inicial detecta el estado asignado. En el camino las unidades 1 y 2 aparecen **omitidas por diagnóstico**, la Unidad 3 es la primera practicable.
11. Comprueba que las unidades omitidas no figuren como exámenes rendidos ni como notas falsas; solamente se registró la decisión pedagógica del profesor.

**Importante:** el diagnóstico es de un solo intento entregado. Un alumno que tenía progreso antes de instalar esta base puede estar exento de repetir diagnóstico; eso no debe usarse para evaluar el flujo de un alumno nuevo.

### 14.2.1 Diagnóstico renovado: 40 tipos de problema (v13.1)

La nueva prueba utiliza **40 enunciados originales, ocho por unidad y 40 planteamientos cognitivos distintos**, distribuidos entre los catorce Objetivos de Aprendizaje (OA) matemáticos del temario adjunto. No se limita a cambiar cifras en una misma historia. Incluye lectura y composición de números, cálculo y estimación, operaciones con dinero, reparto, fracciones representadas en formas distintas, secuencias, ecuaciones, simetría, área y gráficos.

1. Crea un **alumno nuevo**, inscríbelo en un curso y abre su diagnóstico. Comprueba que aparecen 40 preguntas y 60 minutos.
2. Compara preguntas de las cinco unidades: los mecanismos y contextos deben variar. Consulta la **matriz en `docs/matriz-diagnostico-v131.md`** si deseas revisarlas una por una.
3. Comprueba que la nota no aparece al entregarla, que la revisión docente sigue funcionando y que únicamente el profesor asigna la unidad inicial.
4. Si actualizas una base ya utilizada, un diagnóstico iniciado **antes de la actualización** puede continuar con sus preguntas anteriores. Esto es intencional: se conservan las respuestas y no se sustituye su cuestionario a mitad del examen. Solo los intentos nuevos reciben la versión renovada.
5. Repite los pasos con un alumno de nuevo ingreso para confirmar que no puede acceder directamente al camino ni realizar dos diagnósticos.

### 14.2.2 Campanita y bandeja por rol

1. Entra como **alumno**: busca 🔔 arriba a la derecha. El indicador aparece cuando el profesor revisa su examen; púlsalo, lee el aviso y márcalo como leído. El contador debe disminuir.
2. Entra como **docente**: una prueba pendiente produce un aviso. No debe existir un botón «Notificaciones» junto a las demás secciones del panel; se consulta desde la campanita.
3. Entra como **apoderado** vinculado al alumno: una revisión docente genera su propio aviso. Puede consultarlo y marcarlo como leído, sin acceder a avisos de otros apoderados.
4. Verifica que **administrador** también tenga la cabecera común (aunque la bandeja puede estar vacía). El icono no debe quedar bajo la barra del teléfono.
5. Las notificaciones se consultan dentro de la aplicación con el backend activo; **no hay push de Android**.

### 14.3 Preguntas de numeración y alternativa correcta

1. En Unidad 1 o en una prueba que contenga valor posicional, verifica un enunciado semejante a `En [[7]].768, ¿cuánto vale el dígito resaltado?` en la base. En el teléfono el `7` delimitado aparece **destacado con color**; los corchetes no deben ser visibles.
2. Prueba números que tienen dos dígitos iguales. Solo **uno** aparece resaltado y su valor coincide con la opción correcta.
3. Busca valores posicionales: no deberían existir preguntas sobre el valor del dígito **0**.
4. Ante `¿Cuál es el mayor número entre 8.105 y 8.115?` deben verse **exactamente dos alternativas**, 8.105 y 8.115.
5. Revisa también una tanda; el mismo resaltado debe mostrarse en los ejercicios de práctica, no solo en las evaluaciones.

### 14.4 Navegación del camino y repaso

1. En el camino, pulsa la tarjeta **▶ Jugar lección** de la sección actual: debe abrir inmediatamente la tanda.
2. Realiza los ejercicios, usa **Revisar** y corrige los errores. Cumple el estándar para dominar un conjunto.
3. Pulsa una sección verde ya completada. Debe aparecer **¿Quieres volver a jugar esta lección?** con **Sí** y **No**.
4. Pulsa **No**: el camino no cambia. Repite y pulsa **Sí**: la tanda de repaso comienza.
5. Durante la tanda, abre **⚙ Ajustes** en la esquina superior derecha y elige **Salir de la lección**. El botón de salida no debe aparecer en la zona inferior. Vuelve a entrar para retomar respuestas guardadas.
6. Completa la tanda de repaso. La unidad alcanzada **no retrocede**, el progreso del alumno no se sobrescribe y queda constancia de un nuevo intento.
7. Una sección bloqueada no permite comenzar una tanda. Una unidad omitida por diagnóstico tampoco aparece como completada mediante práctica.

### 14.5 Examen final de unidad: 25 preguntas / 50 minutos

1. Termina todas las tandas de la Unidad 1 y completa su último conjunto con el estándar requerido.
2. Abre **Pruebas y ensayo final**: la evaluación de esa unidad debe estar disponible.
3. Iníciala: deben aparecer **25** preguntas, con **50 minutos** de tiempo límite.
4. Usa **Siguiente** y **Anterior**, y comprueba que las respuestas se conservan al salir y volver.
5. Comprueba que ya **no haya botón de salir abajo**, ni en examen ni en lecciones. En la esquina superior derecha pulsa **⚙ Ajustes**, junto a la campanita. Comprueba que aparezca el diálogo de confirmación con «Salir del examen» o «Salir de la lección» y que explique que se guardan las respuestas ya enviadas. En el examen, el tiempo sigue corriendo aunque salgas.
6. Entrega la prueba: el alumno **no** ve su porcentaje ni una aprobación automática. Ve un mensaje de espera.
7. El profesor debe encontrar **todas** las pruebas presentadas en **Pruebas a revisar**, tanto con nota alta como baja; puede ver el puntaje calculado, número de correctas y duración.
8. El docente escribe un comentario obligatorio y decide **Aprobar** o **Reprobar**.
9. Si aprueba, el alumno recibe la decisión y el comentario en la campanita de notificaciones. La siguiente unidad se desbloquea.
10. Si reprueba, el alumno recibe un mensaje de ánimo más el comentario, y puede volver a intentar la prueba sin desbloquear la siguiente unidad.
11. Comprueba que otro docente, no responsable del curso, no puede aprobar esos intentos mediante la API.

**No se desbloquean unidades con notas calculadas automáticamente**: el cambio depende de una decisión del docente verificada por el servidor.

### 14.6 Ensayo final y acceso desde nivel superior

1. Para desbloquear el ensayo, se requiere completar o haber omitido **por diagnóstico** las unidades previas y obtener la autorización docente de la última unidad cursada.
2. Verifica que el ensayo tenga **40 preguntas** originales de distintos ejes, con respuestas guardadas.
3. El docente también ve este ensayo en **Pruebas a revisar** y debe enviar una decisión con comentario escrito.
4. El alumno solo ve esa devolución después de la revisión.

### 14.7 Videollamada integrada en una sola APK

1. En el alumno abre **Hablar con mi profesor** y solicita ayuda.
2. En docente abre **Solicitudes de videollamada**, acepta la solicitud y entra a la sala.
3. Ambos participantes entran desde su APK. No deben abrir Chrome ni instalar Jitsi.
4. Comprueba video y audio en ambas direcciones, interruptores de micrófono y cámara, salida y regreso a Rumbo SIMCE.
5. Comprueba que los tokens se emiten individualmente por el backend y nunca quedan en el archivo `.env` del móvil.

## 15. Pruebas técnicas y verificaciones

En PowerShell, desde `backend` y después de `npm install`:

```powershell
npm run verificar:v13.1
```

Este verificador **no necesita una base de datos** y revisa el banco y las reglas principales. Para las pruebas de integración que crean estudiantes, exámenes y revisiones, primero asegúrate de que Docker creó la base `rumbo_simce_test`, separada de la base habitual, y ejecuta:

```powershell
npm test
```

**Advertencia:** el `globalSetup` de Jest reinicia la base de pruebas configurada en `TEST_DATABASE_URL`. Verifica que apunte a `rumbo_simce_test` y nunca a la base con tus datos. Con este procedimiento se comprueban los cinco exámenes de 25 preguntas, las 40 preguntas del diagnóstico, el bloqueo del camino, la privacidad de resultados y el flujo de aprobación y reintento.

En la carpeta `mobile`:

```powershell
npm run verificar:v13.1
npm run typecheck
npx --no-install expo install --check
```

La comprobación estática no equivale a compilar o instalar una APK real. La aceptación de la versión requiere el resultado de estos comandos más las pruebas en dos teléfonos.

## 16. Solución de problemas comunes

**El teléfono no puede conectarse a la API:** comprueba `ipconfig`, que `mobile/.env` contiene tu IP actual y que en un navegador del teléfono responde `http://IP_PC:3000/api/health`. Revisa firewall, Wi-Fi y reinicia Metro con `-c` después de cambiar `.env`.

**La APK muestra una pantalla gris y se cierra:** conecta el móvil por USB con Depuración USB activada, ejecuta `adb logcat -c`, reproduce el cierre y guarda `adb logcat -d -v time > crash.txt`. Analiza `FATAL EXCEPTION`, `AndroidRuntime` o `UnsatisfiedLinkError` antes de cambiar dependencias.

**Ninja/CMake: `Filename longer than 260 characters`:** cierra Android Studio y Metro, mueve la carpeta completa a una ruta corta (por ejemplo `C:\Rumbo\v131\rumbo-simce`), abre PowerShell en `mobile` y ejecuta `npm run prebuild:android` para regenerar `android` en la nueva ubicación. No reutilices artefactos CMake `.cxx` de la ruta anterior: `prebuild --clean` los retira. Reabre **esa nueva carpeta** `mobile\android` en Android Studio. No necesitas alterar las bibliotecas de LiveKit para resolver este error.

**Gradle utiliza Java 25:** selecciona JDK 21 en Android Studio y confirma el archivo `mobile/android/gradle/gradle-daemon-jvm.properties`, que debe contener `toolchainVersion=21`. En PowerShell establece `JAVA_HOME` a la ruta real de JDK 21 y añade `%JAVA_HOME%\bin` a `Path`. Confirma `./gradlew --version` (en Windows `./gradlew.bat` o `.\gradlew.bat`). Detén Gradle mediante `.\gradlew.bat --stop` y repite.

**No aparece el diagnóstico:** usa un alumno nuevo creado después de preparar la base; los alumnos que ya existían al aplicar una actualización pueden quedar exentos para proteger sus avances. Además, el alumno debe estar inscrito en un curso del profesor.

**El docente no ve la prueba:** comprueba que el estudiante esté inscrito en uno de sus cursos, haya entregado el examen y que no haya recibido ya un dictamen. Pulsa **Actualizar** en la bandeja. Las notificaciones son **internas** a la app, no push del sistema.

**No aparecen 25 preguntas o la corrección pedagógica:** ejecuta `npm run db:seed` desde backend para aplicar migraciones y el catálogo completo de contenido. No basta con copiar solamente el código móvil. `db:seed` reintroduce contenido curricular en orden y aplica sus correcciones al final.

**Videollamada falla:** revisa LiveKit Cloud, las variables `LIVEKIT_URL`, `LIVEKIT_API_KEY`, `LIVEKIT_API_SECRET` en `backend/.env`, Internet y permisos de cámara/micrófono. No copies secretos a `mobile/.env`.

**npm o Expo muestra dependencias incompatibles:** usa las versiones del `package.json` y `npx expo install --check`. Evita actualizar Expo SDK o React Native de versión mayor sin comprobar antes su compatibilidad con LiveKit y WebRTC.

## 17. Seguridad, mantenimiento y distribución

- Este proyecto es una **demostración académica con cuentas ficticias**. No introducir datos sensibles de menores reales. LiveKit Cloud gratuito tiene límites y disponibilidad sujetos al proveedor.
- Nunca publiques archivos `.env`, secrets, tokens, certificados, `node_modules`, carpetas generadas `mobile/android`, `mobile/ios`, APK ni caches de Gradle dentro del ZIP de **código fuente**.
- La revisión pedagógica de los ejercicios corresponde al equipo del proyecto y al profesor asesor. Los tiempos y umbrales de evaluación de esta demostración no son estándares oficiales del SIMCE ni del método Kumon.
- El **diagnóstico de entrada** no es la solicitud de videoconferencia por diagnóstico: son funcionalidades diferentes. Ambas pueden coexistir dentro de la misma aplicación.
- Si necesitas reutilizar datos de una base preexistente, **no** ejecutes `db:reset`: crea copia de seguridad y usa `npm run db:seed` para migrar. El procedimiento de prueba con base nueva es el recomendado para quienes instalan por primera vez.

## 18. Checklist de aceptación de entrega

- [ ] JDK 21 real seleccionado en Android Studio, JAVA_HOME y Gradle Daemon.
- [ ] Node.js, npm, Docker y PostgreSQL instalados y verificados.
- [ ] LiveKit Cloud gratuito configurado con secretos privados en backend.
- [ ] IP local propia configurada en móvil (no `localhost`).
- [ ] `npm run db:reset` y `npm run db:demo` realizados sobre base descartable.
- [ ] `npm run verificar:v13.1` en backend y móvil pasa.
- [ ] `npm run typecheck` y `npm test` pasan tras instalar dependencias.
- [ ] APK debug compila e instala en dos teléfonos.
- [ ] Alumno nuevo ve diagnóstico 40/60 antes del camino; el diagnóstico tiene 40 enfoques diferentes, no 40 cambios de cifras.
- [ ] Docente recibe solicitud de revisión y puede seleccionar Unidad 1-5.
- [ ] Campanita superior, contador correcto y avisos para alumno, profesor y apoderado.
- [ ] Notificación de asignación y unidades previas omitidas funcionan.
- [ ] Digito resaltado, no valor cero y comparación de dos alternativas correctos.
- [ ] Repetir lección confirmando Sí/No y botón de jugar la actual funcionan.
- [ ] Examen de unidad 25/50; «Salir» aparece solo dentro de ⚙ Ajustes, nunca en pie de pantalla.
- [ ] Alumno espera dictamen sin ver su puntaje.
- [ ] Docente ve resultados, tiempo y exige feedback; aprobación y reprobación notificadas.
- [ ] El ensayo y la videoconferencia LiveKit permanecen integrados en una sola APK.

## 19. Referencias de instalación

- Node.js: https://nodejs.org/
- Eclipse Temurin JDK 21: https://adoptium.net/temurin/releases/?version=21
- Android Studio: https://developer.android.com/studio
- Docker Desktop: https://www.docker.com/products/docker-desktop/
- Expo: https://docs.expo.dev/
- Android safe area: https://docs.expo.dev/develop/user-interface/safe-areas/
- LiveKit Cloud: https://cloud.livekit.io/
- LiveKit React Native: https://docs.livekit.io/transport/sdk-platforms/react-native/

**Documento autónomo para la entrega de código fuente.** No requiere haber leído manuales de versiones anteriores.

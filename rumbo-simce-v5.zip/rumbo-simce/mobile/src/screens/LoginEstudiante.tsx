// CU01 — el estudiante entra con el código de 6 letras y su PIN de 4 números.
import { useState } from 'react';
import { StyleSheet, Text, TextInput, View } from 'react-native';
import { api, ApiError } from '../api';
import { BotonGrande } from '../components/BotonGrande';
import { colors, sizes } from '../theme';

interface Props {
  onEntrar: (token: string, apodo: string) => void;
  onVolver: () => void;
}

export function LoginEstudiante({ onEntrar, onVolver }: Props) {
  const [codigo, setCodigo] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [cargando, setCargando] = useState(false);

  async function entrar() {
    setError(null);
    setCargando(true);
    try {
      const res = await api.loginEstudiante(codigo.trim(), pin);
      onEntrar(res.token, res.estudiante.apodo);
    } catch (e) {
      setPin('');
      if (e instanceof ApiError && e.status === 401) setError('Ups, el código o el PIN no coinciden. ¡Inténtalo otra vez!');
      else if (e instanceof ApiError && e.status === 423) setError(`⏳ ${e.message}`); // HU-04: bloqueo temporal
      else setError('No pudimos conectarnos. Revisa internet.');
    } finally {
      setCargando(false);
    }
  }

  return (
    <View style={styles.contenedor}>
      <Text style={styles.titulo}>Tu código secreto</Text>
      <TextInput
        style={styles.input}
        value={codigo}
        onChangeText={(t) => setCodigo(t.toUpperCase())}
        maxLength={6}
        autoCapitalize="characters"
        autoCorrect={false}
        placeholder="ABC123"
        accessibilityLabel="Código de acceso"
      />
      <Text style={styles.titulo}>Tu PIN</Text>
      <TextInput
        style={styles.input}
        value={pin}
        onChangeText={(t) => setPin(t.replace(/\D/g, ''))}
        maxLength={4}
        keyboardType="number-pad"
        secureTextEntry
        placeholder="••••"
        accessibilityLabel="PIN de cuatro números"
      />
      {error && <Text style={styles.error}>{error}</Text>}
      <BotonGrande
        titulo={cargando ? 'Entrando…' : '¡A volar!'}
        onPress={entrar}
        deshabilitado={cargando || codigo.length !== 6 || pin.length !== 4}
      />
      <BotonGrande titulo="Volver" onPress={onVolver} color={colors.blanco} />
    </View>
  );
}

const styles = StyleSheet.create({
  contenedor: { flex: 1, justifyContent: 'center', padding: 24, backgroundColor: colors.cielo },
  titulo: { fontSize: sizes.texto + 2, fontWeight: '700', color: colors.cordillera, marginTop: 12 },
  input: {
    backgroundColor: colors.blanco, borderRadius: sizes.radio, fontSize: 32, letterSpacing: 8,
    textAlign: 'center', paddingVertical: 14, marginVertical: 8, color: colors.texto,
  },
  error: { color: colors.error, fontSize: 18, textAlign: 'center', marginVertical: 8 },
});

// Base del CU10 — mapa de islas. Por ahora lista las 5 islas desde la API y cada una abre
// una misión (CU09). El mapa ilustrado y el avance por eje se construyen en el Sprint 3.
import { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { api, Eje } from '../api';
import { BotonGrande } from '../components/BotonGrande';
import { colors, sizes } from '../theme';

interface Props {
  apodo: string;
  onJugar: (eje: Eje) => void;
  onSalir: () => void;
}

export function Mapa({ apodo, onJugar, onSalir }: Props) {
  const [ejes, setEjes] = useState<Eje[] | null>(null);
  const [error, setError] = useState(false);

  function cargar() {
    setError(false);
    api.ejes().then((r) => setEjes(r.ejes)).catch(() => setError(true));
  }
  useEffect(cargar, []);

  return (
    <View style={styles.contenedor}>
      <Text style={styles.saludo}>¡Hola, {apodo}! 🦅</Text>
      <Text style={styles.sub}>Elige una isla para tu próxima misión</Text>
      {error && (
        <>
          <Text style={styles.sub}>No pudimos cargar el mapa.</Text>
          <BotonGrande titulo="Intentar de nuevo" onPress={cargar} />
        </>
      )}
      {!ejes && !error && <ActivityIndicator size="large" color={colors.cordillera} />}
      {ejes && (
        <FlatList
          data={ejes}
          keyExtractor={(e) => String(e.id)}
          renderItem={({ item }) => (
            <Pressable
              onPress={() => onJugar(item)}
              accessibilityRole="button"
              accessibilityLabel={`${item.isla_nombre}: ${item.nombre}. Jugar una misión`}
              style={({ pressed }) => [styles.isla, pressed && { opacity: 0.85 }]}
            >
              <View style={{ flex: 1 }}>
                <Text style={styles.islaNombre}>🏝️ {item.isla_nombre}</Text>
                <Text style={styles.eje}>{item.nombre}</Text>
              </View>
              <Text style={styles.jugar}>▶</Text>
            </Pressable>
          )}
        />
      )}
      <BotonGrande titulo="Salir" onPress={onSalir} color={colors.blanco} />
    </View>
  );
}

const styles = StyleSheet.create({
  contenedor: { flex: 1, padding: 24, paddingTop: 64, backgroundColor: colors.cielo },
  saludo: { fontSize: sizes.titulo, fontWeight: '800', color: colors.cordillera },
  sub: { fontSize: sizes.texto - 2, color: colors.textoSuave, marginBottom: 16 },
  isla: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: colors.blanco,
    borderRadius: sizes.radio, padding: 18, marginBottom: 12, minHeight: sizes.boton,
  },
  islaNombre: { fontSize: sizes.texto + 2, fontWeight: '700', color: colors.pasto },
  eje: { fontSize: 16, color: colors.textoSuave, marginTop: 4 },
  jugar: { fontSize: 28, color: colors.sol, marginLeft: 12 },
});

// CU09 — Jugar una misión: preguntas de una isla, una a la vez, con resultado inmediato (HU-14)
// y resumen al final (HU-11). El tiempo de cada respuesta se mide aquí y se registra en la API (HU-16).
import { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { api, ApiError, Eje, Mision as MisionApi, ResultadoRespuesta, ResumenMision } from '../api';
import { BotonGrande } from '../components/BotonGrande';
import { colors, sizes } from '../theme';

interface Props {
  eje: Eje;
  onVolver: () => void;
}

type Estado =
  | { tipo: 'cargando' }
  | { tipo: 'error'; texto: string; reintentable: boolean }
  | { tipo: 'jugando' }
  | { tipo: 'resumen'; resumen: ResumenMision };

const mensajeNino = (e: unknown) => {
  if (e instanceof ApiError) return e.message; // los mensajes para el estudiante ya vienen en lenguaje simple
  return 'No pudimos conectarnos. Revisa internet y vuelve a intentarlo.';
};

export function Mision({ eje, onVolver }: Props) {
  const [estado, setEstado] = useState<Estado>({ tipo: 'cargando' });
  const [mision, setMision] = useState<MisionApi | null>(null);
  const [indice, setIndice] = useState(0);
  const [elegida, setElegida] = useState<string | null>(null);
  const [resultado, setResultado] = useState<ResultadoRespuesta | null>(null);
  const [enviando, setEnviando] = useState(false);
  const [errorEnvio, setErrorEnvio] = useState<string | null>(null);
  const inicioPregunta = useRef(Date.now());
  const scroll = useRef<ScrollView>(null);

  // Al llegar el resultado se baja hasta la explicación (en pantallas de 5" queda bajo las opciones).
  useEffect(() => {
    if (resultado) setTimeout(() => scroll.current?.scrollToEnd({ animated: true }), 50);
    else scroll.current?.scrollTo({ y: 0, animated: false });
  }, [resultado]);

  const empezar = useCallback(async () => {
    setEstado({ tipo: 'cargando' });
    setIndice(0); setElegida(null); setResultado(null); setErrorEnvio(null);
    try {
      const res = await api.iniciarMision(eje.id);
      setMision(res.mision);
      inicioPregunta.current = Date.now();
      setEstado({ tipo: 'jugando' });
    } catch (e) {
      const reintentable = !(e instanceof ApiError && (e.code === 'SIN_CONSENTIMIENTO' || e.code === 'SIN_PREGUNTAS'));
      setEstado({ tipo: 'error', texto: mensajeNino(e), reintentable });
    }
  }, [eje.id]);

  useEffect(() => { void empezar(); }, [empezar]);

  async function responder(clave: string) {
    if (!mision || resultado || enviando) return;
    const pregunta = mision.preguntas[indice];
    setElegida(clave);
    setEnviando(true);
    setErrorEnvio(null);
    try {
      const r = await api.responder(mision.id, {
        preguntaId: pregunta.id, opcion: clave, tiempoMs: Date.now() - inicioPregunta.current,
      });
      setResultado(r);
    } catch (e) {
      setElegida(null);
      setErrorEnvio(mensajeNino(e));
    } finally {
      setEnviando(false);
    }
  }

  function siguiente() {
    if (!mision || !resultado) return;
    if (resultado.terminada && resultado.resumen) {
      setEstado({ tipo: 'resumen', resumen: resultado.resumen });
      return;
    }
    setIndice((i) => i + 1);
    setElegida(null);
    setResultado(null);
    inicioPregunta.current = Date.now();
  }

  if (estado.tipo === 'cargando') {
    return (
      <View style={[styles.contenedor, styles.centro]}>
        <ActivityIndicator size="large" color={colors.cordillera} accessibilityLabel="Preparando la misión" />
        <Text style={styles.sub}>Toko está preparando tu misión en {eje.isla_nombre}…</Text>
      </View>
    );
  }

  if (estado.tipo === 'error') {
    return (
      <View style={[styles.contenedor, styles.centro]}>
        <Text style={styles.toko}>🦅</Text>
        <Text style={styles.textoError} accessibilityRole="alert">{estado.texto}</Text>
        {estado.reintentable ? <BotonGrande titulo="Intentar de nuevo" onPress={empezar} /> : null}
        <BotonGrande titulo="Volver al mapa" onPress={onVolver} color={colors.blanco} />
      </View>
    );
  }

  if (estado.tipo === 'resumen') {
    const { correctas, total, duracionSeg } = estado.resumen;
    const estrellas = correctas === total ? 3 : correctas >= Math.ceil(total / 2) ? 2 : correctas > 0 ? 1 : 0;
    const min = Math.floor(duracionSeg / 60);
    const seg = duracionSeg % 60;
    return (
      <View style={[styles.contenedor, styles.centro]}>
        <Text style={styles.titulo} accessibilityRole="header">¡Misión cumplida!</Text>
        <View style={styles.filaEstrellas} accessible accessibilityLabel={`${estrellas} de 3 estrellas`}>
          {[1, 2, 3].map((n) => (
            <Text key={n} style={[styles.estrella, n > estrellas && styles.estrellaApagada]}>⭐</Text>
          ))}
        </View>
        <Text style={styles.resumen}>Respondiste bien {correctas} de {total}</Text>
        <Text style={styles.sub}>Tiempo: {min} min {seg} s</Text>
        <Text style={styles.sub}>
          {estrellas === 3 ? '¡Increíble! Toko está orgulloso de ti.' : '¡Bien hecho! Cada misión te hace más fuerte.'}
        </Text>
        <BotonGrande titulo="Jugar otra misión" onPress={empezar} />
        <BotonGrande titulo="Volver al mapa" onPress={onVolver} color={colors.blanco} />
      </View>
    );
  }

  // Jugando
  const m = mision!;
  const pregunta = m.preguntas[indice];
  return (
    <View style={styles.contenedor}>
      <ScrollView ref={scroll} contentContainerStyle={styles.scroll}>
        <View style={styles.cabecera}>
          <Text style={styles.isla}>🏝️ {m.eje.isla}</Text>
          <Text style={styles.contador} accessibilityLabel={`Pregunta ${indice + 1} de ${m.total}`}>
            {indice + 1} / {m.total}
          </Text>
        </View>
        <View style={styles.barra} accessibilityElementsHidden importantForAccessibility="no-hide-descendants">
          <View style={[styles.barraLlena, { width: `${((indice + (resultado ? 1 : 0)) / m.total) * 100}%` }]} />
        </View>

        <Text style={styles.enunciado} accessibilityRole="header">{pregunta.enunciado}</Text>

        {pregunta.opciones.map((o) => {
          const esElegida = elegida === o.clave;
          const esCorrecta = resultado?.respuestaCorrecta === o.clave;
          const estilo = resultado
            ? esCorrecta ? styles.opcionCorrecta : esElegida ? styles.opcionIncorrecta : styles.opcionApagada
            : esElegida ? styles.opcionElegida : null;
          const marca = resultado ? (esCorrecta ? '✔ ' : esElegida ? '✖ ' : '') : '';
          return (
            <Pressable
              key={o.clave}
              accessibilityRole="button"
              accessibilityLabel={`Opción ${o.clave}: ${o.texto}`}
              accessibilityState={{ disabled: Boolean(resultado) || enviando, selected: esElegida }}
              disabled={Boolean(resultado) || enviando}
              onPress={() => responder(o.clave)}
              style={({ pressed }) => [styles.opcion, estilo, pressed && !resultado && { opacity: 0.85 }]}
            >
              <Text style={styles.claveOpcion}>{o.clave}</Text>
              <Text style={styles.textoOpcion}>{marca}{o.texto}</Text>
            </Pressable>
          );
        })}

        {enviando ? <ActivityIndicator color={colors.cordillera} style={{ marginTop: 12 }} /> : null}
        {errorEnvio ? <Text style={styles.textoError} accessibilityRole="alert">{errorEnvio}</Text> : null}

        {resultado ? (
          <View
            style={[styles.feedback, resultado.correcta ? styles.feedbackBien : styles.feedbackMal]}
            accessibilityRole="alert"
            accessibilityLiveRegion="polite"
          >
            <Text style={styles.feedbackTitulo}>
              {resultado.correcta ? '¡Muy bien! 🎉' : `Casi… la respuesta era la ${resultado.respuestaCorrecta}`}
            </Text>
            <Text style={styles.feedbackTexto}>{resultado.explicacion}</Text>
          </View>
        ) : null}
      </ScrollView>

      <View style={styles.pie}>
        {resultado ? (
          <BotonGrande titulo={resultado.terminada ? 'Ver mi resultado' : 'Siguiente'} onPress={siguiente} />
        ) : (
          <BotonGrande titulo="Salir de la misión" onPress={onVolver} color={colors.blanco} />
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  contenedor: { flex: 1, backgroundColor: colors.cielo },
  centro: { justifyContent: 'center', padding: 24 },
  scroll: { padding: 20, paddingTop: 56, paddingBottom: 24, maxWidth: 560, width: '100%', alignSelf: 'center' },
  cabecera: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  isla: { fontSize: 18, fontWeight: '700', color: colors.pasto },
  contador: { fontSize: 18, fontWeight: '700', color: colors.cordillera },
  barra: { height: 12, borderRadius: 6, backgroundColor: colors.blanco, marginVertical: 12, overflow: 'hidden' },
  barraLlena: { height: '100%', backgroundColor: colors.sol },
  enunciado: { fontSize: 24, fontWeight: '700', color: colors.texto, marginVertical: 16, lineHeight: 32 },
  opcion: {
    flexDirection: 'row', alignItems: 'center', minHeight: sizes.boton, borderRadius: sizes.radio,
    backgroundColor: colors.blanco, paddingHorizontal: 16, paddingVertical: 12, marginVertical: 6,
    borderWidth: 3, borderColor: 'transparent',
  },
  opcionElegida: { borderColor: colors.cordillera },
  opcionCorrecta: { borderColor: colors.pasto, backgroundColor: '#E6F4EA' },
  opcionIncorrecta: { borderColor: colors.error, backgroundColor: '#FBE9E7' },
  opcionApagada: { opacity: 0.6 },
  claveOpcion: {
    width: 40, height: 40, borderRadius: 20, backgroundColor: colors.cielo, textAlign: 'center',
    lineHeight: 40, fontSize: 20, fontWeight: '800', color: colors.cordillera, marginRight: 12, overflow: 'hidden',
  },
  textoOpcion: { flex: 1, fontSize: sizes.texto, color: colors.texto, fontWeight: '600' },
  feedback: { borderRadius: sizes.radio, padding: 16, marginTop: 16, borderLeftWidth: 8 },
  feedbackBien: { backgroundColor: '#E6F4EA', borderLeftColor: colors.pasto },
  feedbackMal: { backgroundColor: '#FFF4E0', borderLeftColor: colors.sol },
  feedbackTitulo: { fontSize: 20, fontWeight: '800', color: colors.texto, marginBottom: 6 },
  feedbackTexto: { fontSize: 18, color: colors.texto, lineHeight: 26 },
  pie: { padding: 16, paddingBottom: 28, backgroundColor: colors.cielo, maxWidth: 560, width: '100%', alignSelf: 'center' },
  toko: { fontSize: 80, textAlign: 'center' },
  titulo: { fontSize: sizes.titulo, fontWeight: '800', color: colors.cordillera, textAlign: 'center' },
  filaEstrellas: { flexDirection: 'row', justifyContent: 'center', marginVertical: 12, gap: 6 },
  estrella: { fontSize: 48 },
  estrellaApagada: { opacity: 0.2 },
  resumen: { fontSize: 24, fontWeight: '700', color: colors.texto, textAlign: 'center' },
  sub: { fontSize: 18, color: colors.textoSuave, textAlign: 'center', marginVertical: 6 },
  textoError: { fontSize: 19, color: colors.error, textAlign: 'center', marginVertical: 12 },
});

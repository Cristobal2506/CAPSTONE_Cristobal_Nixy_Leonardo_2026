# Rumbo SIMCE

App móvil de preparación adaptativa para el SIMCE de Matemática de 4° básico — cliente **Triskel Edu**.
Proyecto APT · Capstone PTY4614 · Duoc UC — Cristóbal Muñoz, Nixy Silva, Leonardo Figueroa.

```
rumbo-simce/
├── backend/        API REST (Node 22 + Express 5 + PostgreSQL 16)
│   ├── migrations/ esquema SQL versionado (modelo de datos del Informe Fase 1)
│   ├── seeds/      datos base (5 ejes / islas)
│   ├── src/        rutas, middlewares, configuración
│   └── tests/      pruebas de aceptación por caso de uso (Jest + Supertest)
├── mobile/         app del estudiante (Expo / React Native + TypeScript)
├── docs/           catálogo de casos de uso y decisiones de diseño
└── .github/        CI: pruebas de la API + typecheck de la app en cada push/PR
```

El panel web de reportes (React) se agrega en el Sprint 6 como `web/`.

## Puesta en marcha

Requisitos: Node 22, Docker (o un PostgreSQL 16 local), app **Expo Go** en el teléfono.

```bash
# 1. Base de datos
docker compose up -d            # crea rumbo_simce y rumbo_simce_test

# 2. API
cd backend
cp .env.example .env
npm install
npm run db:reset                # crea tablas + carga ejes, tipos de error y 37 preguntas
npm run db:demo                 # crea usuarios de prueba (ver abajo)
npm run dev                     # http://localhost:3000/api/health
npm test                        # 57 pruebas, usan la base rumbo_simce_test

# 3. App móvil (en otra terminal)
cd mobile
cp .env.example .env            # y cambia la IP por la de tu computador
npm install
npx expo start                  # escanea el QR con Expo Go
```

### Usuarios de prueba (`npm run db:demo`)

| Perfil | Credenciales |
|---|---|
| Estudiante | código `RUMB24` · PIN `1234` |
| Apoderado | `apoderado@demo.cl` · `demo1234` |
| Docente | `docente@demo.cl` · `demo1234` |
| Administrador (banco de preguntas) | `admin@demo.cl` · `demo1234` |

### Si el celular no se conecta

- Celular y computador deben estar en la **misma red wifi**. Las redes de universidad suelen bloquear la conexión entre equipos: usa el hotspot del celular.
- En `mobile/.env` va la IP del computador, nunca `localhost`. Después de cambiarla, reinicia con `npx expo start -c`.
- Windows: cuando el Firewall pregunte por Node.js, permite el acceso en **redes privadas**.
- Prueba primero en el navegador del celular: `http://TU_IP:3000/api/health` debe responder `{"ok":true}`.

## Endpoints disponibles (Sprints 1 y 2)

| Método | Ruta | Rol | CU / HU |
|---|---|---|---|
| POST | `/api/auth/registro` | público | CU02 |
| POST | `/api/auth/login` | público (adultos) | CU01 · HU-04 |
| POST | `/api/auth/login-estudiante` | público (código + PIN) | CU01 · HU-04 |
| POST | `/api/auth/recuperar` | público — envía un código de 6 dígitos al correo | CU07 |
| POST | `/api/auth/restablecer` | público — `{ email, codigo, password }` | CU07 |
| GET | `/api/me` | cualquiera autenticado | CU01 · HU-05 |
| PATCH | `/api/me` | adulto: `{ nombre }` · estudiante: `{ avatar }` | HU-06 |
| POST | `/api/me/password` | adultos — `{ actual, nueva }` | HU-06 |
| GET/POST/DELETE | `/api/apoderado/consentimiento` | apoderado | CU03 |
| GET | `/api/apoderado/consentimiento/texto` | apoderado — texto versionado que se lee antes de aceptar | CU03 · HU-29 |
| GET/POST | `/api/apoderado/estudiantes` | apoderado | CU04 |
| POST | `/api/apoderado/estudiantes/:id/curso` | apoderado | CU06 |
| GET/POST | `/api/docente/cursos` | docente | CU05 |
| GET | `/api/docente/cursos/:id/estudiantes` | docente | CU05/CU17 |
| GET | `/api/ejes` | cualquiera autenticado | CU10 |
| POST | `/api/estudiante/misiones` | estudiante — `{ ejeId }`, exige consentimiento vigente | CU09 · HU-11 |
| GET | `/api/estudiante/misiones/:id` | estudiante — estado y resumen | CU09 |
| POST | `/api/estudiante/misiones/:id/respuestas` | estudiante — `{ preguntaId, opcion, tiempoMs }` | CU09 · HU-14 / HU-16 |
| GET | `/api/admin/preguntas` | admin — filtros `?eje=&dificultad=&activa=&revisada=` | CU08 |
| GET | `/api/admin/preguntas/resumen` | admin — cobertura por eje y nivel | CU08 |
| GET/POST/PATCH/DELETE | `/api/admin/preguntas[/:id]` | admin — DELETE desactiva, no borra | CU08 |
| GET | `/api/admin/tipos-error` | admin — catálogo de errores típicos | CU08 |

Errores siempre con la forma `{ "error": { "code": "...", "message": "..." } }`.
Una cuenta bloqueada responde **423** `CUENTA_BLOQUEADA` con `reintentarEnMinutos`.

### Correo de recuperación (CU07)

Se configura con `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS` y `MAIL_FROM` en `backend/.env`
(sirve cualquier proveedor SMTP: Gmail con contraseña de aplicación, Brevo, Mailtrap…).
**Sin `SMTP_HOST`, en desarrollo el correo con el código aparece en la consola donde corre `npm run dev`.**
En producción la API no arranca sin SMTP configurado.

## Cómo trabajamos (RNF06)

- `main` = lo que se muestra al docente/cliente. `develop` = integración del sprint.
- Una rama por caso de uso: `feature/CU09-jugar-mision`, `fix/CU01-mensaje-error`.
- Pull Request hacia `develop` con **al menos una revisión** de otro integrante y CI en verde.
- Cada CU nuevo trae su archivo de pruebas en `backend/tests/` (criterio de aceptación de la Tabla 8).
- Cambios de base de datos = **nuevo archivo** en `migrations/` (`002_...sql`); nunca editar uno ya aplicado.
- Commits en español e imperativo: `CU04: valida consentimiento antes de crear estudiante`.

## Decisiones de privacidad (Ley 21.719)

- El estudiante no tiene correo ni RUT: solo apodo, avatar, código de acceso y PIN (hash).
- No se puede crear un estudiante sin consentimiento vigente del apoderado; el consentimiento se revoca, no se borra (trazabilidad).
- El docente ve apodo y avatar de sus estudiantes, nunca sus credenciales.
- Contraseñas y PIN con bcrypt. El código de recuperación se guarda como HMAC, sirve una vez, vence en 30 min y se anula tras 5 intentos erróneos; máximo 3 correos cada 15 min por cuenta.
- Tras 5 intentos fallidos de inicio de sesión (adulto o estudiante) la cuenta se bloquea 15 min (configurable). Sin esto, un PIN de 4 dígitos se adivina en minutos.
- La bitácora `evento_acceso` registra inicios de sesión, bloqueos y cambios de contraseña, sin IP ni dispositivo.
- En la app, la sesión se guarda cifrada en el dispositivo (expo-secure-store) y se borra al cerrar sesión.

- Para jugar una misión el estudiante necesita que **su apoderado tenga el consentimiento vigente**; si se retira, la API deja de registrar respuestas.
- La misión nunca envía al teléfono la respuesta correcta ni los tipos de error: se conocen solo después de responder.

## Banco de preguntas (CU08)

- `seeds/002_tipos_error.sql`: catálogo de errores típicos por eje. Cada opción incorrecta de una pregunta apunta a uno (base de HU-16 y del CU14).
- `seeds/003_preguntas.sql`: 37 preguntas de 4° básico (7–8 por eje, niveles 1 a 3). **Borrador del equipo**: todas quedan
  *pendientes de revisión pedagógica* hasta que Triskel Edu las valide.
- En producción (`NODE_ENV=production`) las misiones usan **solo preguntas revisadas** (`MISION_SOLO_REVISADAS`).
- El administrador revisa, activa o desactiva preguntas desde la app (pantalla «Banco de preguntas») y crea o edita contenido por la API.

Ver `docs/casos-de-uso.md` para el catálogo completo y la planificación por sprint.

import { StatusBar } from 'expo-status-bar';
import { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { api, ApiError, Estudiante, onSesionExpirada, setToken, Usuario } from './src/api';
import { borrarSesion, guardarSesion, leerSesion } from './src/sesion';
import { BancoPreguntas } from './src/screens/BancoPreguntas';
import { Bienvenida } from './src/screens/Bienvenida';
import { Consentimiento } from './src/screens/Consentimiento';
import { LoginAdulto } from './src/screens/LoginAdulto';
import { LoginEstudiante } from './src/screens/LoginEstudiante';
import { MisCursos } from './src/screens/MisCursos';
import { MiCamino } from './src/screens/MiCamino';
import { MisEstudiantes } from './src/screens/MisEstudiantes';
import { PanelAdulto } from './src/screens/PanelAdulto';
import { Perfil } from './src/screens/Perfil';
import { RecuperarClave } from './src/screens/RecuperarClave';
import { Registro } from './src/screens/Registro';
import { SecuenciaKumon } from './src/screens/SecuenciaKumon';
import { Tanda } from './src/screens/Tanda';
import { colors } from './src/theme';

// Navegación mínima por estado (Sprints 1–2).
// TODO Sprint 3: migrar a Expo Router (ya hay 14 pantallas y el botón «atrás» de Android no las recorre).
type Pantalla =
  | { tipo: 'cargando' }
  | { tipo: 'bienvenida' }
  | { tipo: 'loginEstudiante' }
  | { tipo: 'loginAdulto'; aviso?: string }
  | { tipo: 'registro' }
  | { tipo: 'recuperar'; email: string }
  | { tipo: 'camino'; apodo: string; avatar?: string }
  | { tipo: 'tanda'; apodo: string; avatar?: string }
  | { tipo: 'panelAdulto'; usuario: Usuario }
  | { tipo: 'perfil'; usuario: Usuario }
  | { tipo: 'consentimiento'; usuario: Usuario; volverA: 'panel' | 'estudiantes' }
  | { tipo: 'estudiantes'; usuario: Usuario }
  | { tipo: 'cursos'; usuario: Usuario }
  | { tipo: 'banco'; usuario: Usuario }
  | { tipo: 'secuencia'; usuario: Usuario };

export default function App() {
  const [pantalla, setPantalla] = useState<Pantalla>({ tipo: 'cargando' });

  // CU01 — cerrar sesión: olvida el token en memoria y en el dispositivo.
  const salir = useCallback(async () => {
    setToken(null);
    await borrarSesion();
    setPantalla({ tipo: 'bienvenida' });
  }, []);

  // CU01 — al abrir la app se recupera la sesión guardada.
  useEffect(() => {
    onSesionExpirada(() => { void salir(); });
    (async () => {
      const guardada = await leerSesion();
      if (!guardada) return setPantalla({ tipo: 'bienvenida' });
      setToken(guardada.token);
      try {
        const perfil = await api.me(); // valida que el token siga vigente y trae datos frescos
        if (perfil.rol === 'estudiante') setPantalla({ tipo: 'camino', apodo: perfil.estudiante.apodo, avatar: perfil.estudiante.avatar });
        else setPantalla({ tipo: 'panelAdulto', usuario: perfil.usuario });
      } catch (e) {
        if (e instanceof ApiError) return salir(); // token vencido o cuenta inexistente
        // Sin conexión: se entra con los datos guardados; las pantallas avisan si no cargan.
        if (guardada.rol === 'estudiante') setPantalla({ tipo: 'camino', apodo: guardada.nombre, avatar: guardada.avatar });
        else salir(); // el panel del adulto necesita conexión
      }
    })();
  }, [salir]);

  async function iniciarSesionEstudiante(token: string, estudiante: Estudiante) {
    setToken(token);
    await guardarSesion({ token, rol: 'estudiante', nombre: estudiante.apodo, avatar: estudiante.avatar });
    setPantalla({ tipo: 'camino', apodo: estudiante.apodo, avatar: estudiante.avatar });
  }

  async function iniciarSesionAdulto(token: string, usuario: Usuario) {
    setToken(token);
    await guardarSesion({ token, rol: usuario.rol, nombre: usuario.nombre });
    setPantalla({ tipo: 'panelAdulto', usuario });
  }

  let contenido;
  switch (pantalla.tipo) {
    case 'cargando':
      contenido = (
        <View style={styles.cargando}>
          <ActivityIndicator size="large" color={colors.cordillera} accessibilityLabel="Cargando" />
        </View>
      );
      break;
    case 'bienvenida':
      contenido = (
        <Bienvenida
          onEstudiante={() => setPantalla({ tipo: 'loginEstudiante' })}
          onAdulto={() => setPantalla({ tipo: 'loginAdulto' })}
        />
      );
      break;
    case 'loginEstudiante':
      contenido = <LoginEstudiante onEntrar={iniciarSesionEstudiante} onVolver={salir} />;
      break;
    case 'loginAdulto':
      contenido = (
        <LoginAdulto
          aviso={pantalla.aviso}
          onEntrar={iniciarSesionAdulto}
          onRegistrarse={() => setPantalla({ tipo: 'registro' })}
          onOlvideClave={(email) => setPantalla({ tipo: 'recuperar', email })}
          onVolver={salir}
        />
      );
      break;
    case 'registro':
      contenido = <Registro onRegistrado={iniciarSesionAdulto} onVolver={() => setPantalla({ tipo: 'loginAdulto' })} />;
      break;
    case 'recuperar':
      contenido = (
        <RecuperarClave
          emailInicial={pantalla.email}
          onListo={() => setPantalla({ tipo: 'loginAdulto', aviso: 'Contraseña actualizada. Ya puedes ingresar.' })}
          onVolver={() => setPantalla({ tipo: 'loginAdulto' })}
        />
      );
      break;
    case 'camino':
      // CU10 — progresión lineal Kumon (reemplaza al mapa de islas tras la 2.ª revisión del cliente)
      contenido = (
        <MiCamino apodo={pantalla.apodo} avatar={pantalla.avatar} onSalir={salir}
          onHacerTanda={() => setPantalla({ tipo: 'tanda', apodo: pantalla.apodo, avatar: pantalla.avatar })} />
      );
      break;
    case 'tanda':
      contenido = <Tanda onVolver={() => setPantalla({ tipo: 'camino', apodo: pantalla.apodo, avatar: pantalla.avatar })} />;
      break;
    case 'panelAdulto':
      contenido = (
        <PanelAdulto
          usuario={pantalla.usuario}
          onIr={(destino) =>
            setPantalla(destino === 'consentimiento'
              ? { tipo: 'consentimiento', usuario: pantalla.usuario, volverA: 'panel' }
              : { tipo: destino, usuario: pantalla.usuario })}
          onSalir={salir}
        />
      );
      break;
    case 'consentimiento': {
      const { usuario, volverA } = pantalla;
      contenido = (
        <Consentimiento
          onVolver={() => setPantalla(volverA === 'estudiantes' ? { tipo: 'estudiantes', usuario } : { tipo: 'panelAdulto', usuario })}
          onAceptado={() => setPantalla({ tipo: 'estudiantes', usuario })}
        />
      );
      break;
    }
    case 'estudiantes': {
      const { usuario } = pantalla;
      contenido = (
        <MisEstudiantes
          onIrAConsentimiento={() => setPantalla({ tipo: 'consentimiento', usuario, volverA: 'estudiantes' })}
          onVolver={() => setPantalla({ tipo: 'panelAdulto', usuario })}
        />
      );
      break;
    }
    case 'cursos': {
      const { usuario } = pantalla;
      contenido = <MisCursos onVolver={() => setPantalla({ tipo: 'panelAdulto', usuario })} />;
      break;
    }
    case 'secuencia': {
      const { usuario } = pantalla;
      contenido = <SecuenciaKumon onVolver={() => setPantalla({ tipo: 'panelAdulto', usuario })} />;
      break;
    }
    case 'banco': {
      const { usuario } = pantalla;
      contenido = <BancoPreguntas onVolver={() => setPantalla({ tipo: 'panelAdulto', usuario })} />;
      break;
    }
    case 'perfil': {
      const actual = pantalla.usuario;
      contenido = (
        <Perfil
          onActualizado={async (usuario) => {
            setPantalla({ tipo: 'perfil', usuario });
            const guardada = await leerSesion();
            if (guardada) await guardarSesion({ ...guardada, nombre: usuario.nombre });
          }}
          onVolver={() => setPantalla({ tipo: 'panelAdulto', usuario: actual })}
        />
      );
      break;
    }
  }

  return (
    <>
      {contenido}
      <StatusBar style="dark" />
    </>
  );
}

const styles = StyleSheet.create({
  cargando: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.cielo },
});

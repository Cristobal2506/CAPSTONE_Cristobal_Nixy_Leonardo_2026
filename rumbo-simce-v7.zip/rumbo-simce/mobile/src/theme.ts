// Paleta provisoria (Andes): ajustar con el diseño definitivo. Contraste AA (RNF08).
export const colors = {
  cielo: '#E8F3FB',
  cordillera: '#2E4A62',
  sol: '#F2A93B',
  pasto: '#3E8E5E',
  error: '#B3261E',
  blanco: '#FFFFFF',
  texto: '#1B2733',
  textoSuave: '#4A5A6A',
};

// RNF01: botones grandes para manos de 9–10 años (mínimo 56 px de alto).
export const sizes = { boton: 64, radio: 18, titulo: 30, texto: 20 };

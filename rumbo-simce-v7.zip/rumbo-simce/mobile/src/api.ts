// Cliente HTTP de la API de Rumbo SIMCE.
// En un teléfono físico "localhost" no apunta a tu PC: define EXPO_PUBLIC_API_URL
// con la IP de tu computador en la red local, ej: http://192.168.1.20:3000/api
const BASE_URL = process.env.EXPO_PUBLIC_API_URL ?? 'http://localhost:3000/api';

export type Rol = 'estudiante' | 'apoderado' | 'docente' | 'admin';
export type RolAdulto = Exclude<Rol, 'estudiante'>;

export interface Eje {
  id: number;
  codigo: string;
  nombre: string;
  isla_nombre: string;
  orden: number;
}

export interface Usuario {
  id: number;
  email: string;
  nombre: string;
  rol: RolAdulto;
}

export interface Estudiante {
  id: number;
  apodo: string;
  avatar: string;
  curso_id?: number | null;
}

// CU03
export interface Consentimiento {
  id: number;
  version_texto: string;
  otorgado_en: string;
}
export interface TextoConsentimiento {
  version: string;
  borrador: boolean;
  titulo: string;
  secciones: { titulo: string; puntos: string[] }[];
}

// CU04 / CU06 — estudiante visto por su apoderado
export interface EstudianteDeApoderado {
  id: number;
  apodo: string;
  avatar: string;
  codigo_acceso: string;
  curso_id: number | null;
  curso: string | null;
}

// CU05
export interface Curso {
  id: number;
  nombre: string;
  establecimiento: string | null;
  anio: number;
  codigo_union: string;
  estudiantes?: number;
}

// CU09
export interface OpcionJuego { clave: string; texto: string }
export interface PreguntaJuego { id: number; enunciado: string; opciones: OpcionJuego[] }
export interface Mision {
  id: number;
  eje: { id: number; codigo: string; nombre: string; isla: string };
  total: number;
  preguntas: PreguntaJuego[];
}
export interface ResumenMision { total: number; respondidas: number; correctas: number; duracionSeg: number }
/** Estado completo de una misión (GET /misiones/:id y /misiones/abierta) — HU-12 */
export interface EstadoMision extends Mision {
  estado: 'abierta' | 'terminada' | 'abandonada';
  respondidas: { preguntaId: number; correcta: boolean }[];
  resumen: ResumenMision | null;
}

// CU11 — progreso por eje
export interface ProgresoEje {
  eje: { id: number; codigo: string; nombre: string; isla: string };
  misionesTerminadas: number;
  respondidas: number;
  correctas: number;
  porcentajeAcierto: number | null;
  aciertoReciente: number | null;
  nivel: number;
  ultimaMision: string | null;
}
export interface ResultadoRespuesta {
  correcta: boolean;
  respuestaCorrecta: string;
  explicacion: string;
  progreso: { respondidas: number; total: number };
  terminada: boolean;
  resumen: ResumenMision | null;
}

// CU08
export interface PreguntaBanco {
  id: number;
  codigo: string | null;
  ejeId: number;
  eje: string;
  enunciado: string;
  opciones: { clave: string; texto: string; tipoError: string | null }[];
  respuestaCorrecta: string;
  dificultad: number;
  estrategia: string;
  explicacion: string;
  activa: boolean;
  revisadaPedagogicamente: boolean;
  vecesRespondida: number;
  porcentajeAcierto: number | null;
}
/** Lo que se envía para crear o editar una pregunta (CU08). */
export interface PreguntaEntrada {
  ejeId: number;
  codigo?: string;
  enunciado: string;
  opciones: { clave: string; texto: string; tipoError?: string | null }[];
  respuestaCorrecta: string;
  dificultad: number;
  estrategia: string;
  explicacion: string;
}
export interface TipoError { codigo: string; descripcion: string; eje: string | null }

export interface ResumenEjeBanco {
  id: number;
  codigo: string;
  nombre: string;
  isla: string;
  activas: number;
  inactivas: number;
  revisadas: number;
  porDificultad: Record<string, number>;
}

// ═════════ Motor Kumon (2.ª revisión del cliente) ═════════
export type EstadoConjunto = 'dominado' | 'actual' | 'bloqueado';
export interface ConjuntoCamino {
  id: number; codigo: string; titulo: string; objetivoAprendizaje: string; tiempoEstandarSeg: number;
  estado: EstadoConjunto; intentos: number; mejorTiempoSeg: number | null;
}
export interface NivelCamino { id: number; codigo: string; nombre: string; estado: EstadoConjunto; conjuntos: ConjuntoCamino[] }
export interface Camino {
  niveles: NivelCamino[]; conjuntoActualId: number; tandaAbiertaId: number | null;
  cierreNivelPendiente: boolean; requiereProfesor: boolean;
}
export interface HojaTanda {
  id: number; orden: number;
  ejemplo: { enunciado: string; resolucion: string };
  ejercicios: { id: number; enunciado: string; opciones: OpcionJuego[] }[];
}
export type Decision = 'avanzar' | 'repetir' | 'retroceder';
export interface ResultadoTanda {
  correctasPrimeraVuelta: number; total: number; tiempoSeg: number; tiempoEstandarSeg: number;
  rondas: number; cumpleEstandar: boolean; decision: Decision;
}
export interface Tanda {
  id: number; repeticion: number; ronda: number; iniciadoEn: string; total: number; tiempoEstandarSeg: number;
  terminado: boolean;
  conjunto: { codigo: string; titulo: string; objetivoAprendizaje: string; nivel: string };
  hojas: HojaTanda[];
  pendientes: number[];
  respuestas: { preguntaId: number; opcion: string }[];
  correctasAnteriores: number[];
  resultado: ResultadoTanda | null;
}
export type Revision =
  | { terminado: false; ronda: number; aCorregir: number[]; correctas: number[] }
  | { terminado: true; resultado: ResultadoTanda };
export interface ConjuntoAdmin {
  id: number; codigo: string; titulo: string; objetivoAprendizaje: string; tiempoEstandarSeg: number;
  activo: boolean; hojas: number; ejercicios: number; intentos: number; porcentajeCumpleEstandar: number | null;
}
export interface NivelAdmin { id: number; codigo: string; nombre: string; conjuntos: ConjuntoAdmin[] }
export interface DetalleConjunto {
  id: number; codigo: string; titulo: string; objetivoAprendizaje: string; tiempoEstandarSeg: number;
  hojas: { id: number; orden: number; ejemplo: { enunciado: string; resolucion: string };
    ejercicios: { id: number; codigo: string; enunciado: string; respuestaCorrecta: string }[] }[];
}

export type Perfil = { rol: 'estudiante'; estudiante: Estudiante } | { rol: RolAdulto; usuario: Usuario };

export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public reintentarEnMinutos?: number,
  ) {
    super(message);
  }
}

/** Error de red (sin internet, servidor apagado, IP mal configurada). */
export const esErrorDeRed = (e: unknown) => !(e instanceof ApiError);

let token: string | null = null;
let alExpirarSesion: (() => void) | null = null;

export const setToken = (t: string | null) => { token = t; };
/** La app registra aquí qué hacer si el token vence (volver a la bienvenida). */
export const onSesionExpirada = (fn: () => void) => { alExpirarSesion = fn; };

const TIEMPO_ESPERA_MS = 15000;

async function request<T>(path: string, options: { method?: string; body?: unknown } = {}): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIEMPO_ESPERA_MS);
  let res: Response;
  try {
    res = await fetch(`${BASE_URL}${path}`, {
      method: options.method ?? 'GET',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: options.body ? JSON.stringify(options.body) : undefined,
      signal: controller.signal,
    });
  } finally {
    clearTimeout(timer);
  }
  const data = res.status === 204 ? null : await res.json().catch(() => null);
  if (!res.ok) {
    const err = data?.error ?? {};
    if (res.status === 401 && err.code === 'TOKEN_INVALIDO' && token) alExpirarSesion?.();
    throw new ApiError(res.status, err.code ?? 'ERROR', err.message ?? 'Error del servidor', err.reintentarEnMinutos);
  }
  return data as T;
}

export const api = {
  // CU01
  loginEstudiante: (codigo: string, pin: string) =>
    request<{ token: string; estudiante: Estudiante }>('/auth/login-estudiante', { method: 'POST', body: { codigo, pin } }),
  loginAdulto: (email: string, password: string) =>
    request<{ token: string; usuario: Usuario }>('/auth/login', { method: 'POST', body: { email, password } }),
  // CU02
  registro: (datos: { nombre: string; email: string; password: string; rol: 'apoderado' | 'docente' }) =>
    request<{ token: string; usuario: Usuario }>('/auth/registro', { method: 'POST', body: datos }),
  // CU07
  recuperar: (email: string) =>
    request<{ mensaje: string }>('/auth/recuperar', { method: 'POST', body: { email } }),
  restablecer: (email: string, codigo: string, password: string) =>
    request<{ mensaje: string }>('/auth/restablecer', { method: 'POST', body: { email, codigo, password } }),
  // HU-05 / HU-06
  me: () => request<Perfil>('/me'),
  editarNombre: (nombre: string) => request<{ usuario: Usuario }>('/me', { method: 'PATCH', body: { nombre } }),
  cambiarPassword: (actual: string, nueva: string) =>
    request<{ mensaje: string }>('/me/password', { method: 'POST', body: { actual, nueva } }),
  // Mapa
  ejes: () => request<{ ejes: Eje[] }>('/ejes'),

  // CU03 — consentimiento (apoderado)
  consentimiento: () =>
    request<{ versionVigente: string; consentimiento: Consentimiento | null }>('/apoderado/consentimiento'),
  textoConsentimiento: () => request<TextoConsentimiento>('/apoderado/consentimiento/texto'),
  aceptarConsentimiento: () =>
    request<{ consentimiento: Consentimiento }>('/apoderado/consentimiento', { method: 'POST', body: { acepta: true } }),
  revocarConsentimiento: () => request<null>('/apoderado/consentimiento', { method: 'DELETE' }),

  // CU04 / CU06 — estudiantes del apoderado
  misEstudiantes: () => request<{ estudiantes: EstudianteDeApoderado[] }>('/apoderado/estudiantes'),
  crearEstudiante: (datos: { apodo: string; avatar: string; pin: string }) =>
    request<{ estudiante: { id: number; apodo: string; avatar: string; codigo_acceso: string } }>(
      '/apoderado/estudiantes', { method: 'POST', body: datos }),
  inscribirEnCurso: (estudianteId: number, codigoCurso: string) =>
    request<{ curso: { id: number; nombre: string } }>(
      `/apoderado/estudiantes/${estudianteId}/curso`, { method: 'POST', body: { codigoCurso } }),

  // CU05 — cursos del docente
  misCursos: () => request<{ cursos: Curso[] }>('/docente/cursos'),
  crearCurso: (datos: { nombre: string; establecimiento?: string }) =>
    request<{ curso: Curso }>('/docente/cursos', { method: 'POST', body: datos }),
  estudiantesDeCurso: (cursoId: number) =>
    request<{ estudiantes: { id: number; apodo: string; avatar: string }[] }>(`/docente/cursos/${cursoId}/estudiantes`),

  // CU09 — misiones (estudiante)
  iniciarMision: (ejeId: number) => request<{ mision: Mision }>('/estudiante/misiones', { method: 'POST', body: { ejeId } }),
  responder: (misionId: number, datos: { preguntaId: number; opcion: string; tiempoMs: number }) =>
    request<ResultadoRespuesta>(`/estudiante/misiones/${misionId}/respuestas`, { method: 'POST', body: datos }),
  // HU-12
  misionAbierta: (ejeId: number) => request<{ mision: EstadoMision | null }>(`/estudiante/misiones/abierta?ejeId=${ejeId}`),
  abandonarMision: (misionId: number) => request<null>(`/estudiante/misiones/${misionId}/abandonar`, { method: 'POST' }),
  // CU11
  progreso: () => request<{ ejes: ProgresoEje[] }>('/estudiante/progreso'),

  // Kumon — estudiante (CU09 / CU10 / CU11 / CU12 / CU13)
  camino: () => request<Camino>('/estudiante/camino'),
  iniciarTanda: () => request<{ tanda: Tanda; retomada: boolean }>('/estudiante/tandas', { method: 'POST' }),
  responderTanda: (tandaId: number, preguntaId: number, opcion: string) =>
    request<{ ronda: number; respondidas: number; porResponder: number }>(
      `/estudiante/tandas/${tandaId}/respuestas`, { method: 'POST', body: { preguntaId, opcion } }),
  revisarTanda: (tandaId: number) => request<Revision>(`/estudiante/tandas/${tandaId}/revisar`, { method: 'POST' }),

  // Kumon — administrador (CU18)
  secuencia: () => request<{ niveles: NivelAdmin[] }>('/admin/secuencia'),
  conjuntoAdmin: (id: number) => request<{ conjunto: DetalleConjunto }>(`/admin/conjuntos/${id}`),
  editarConjunto: (id: number, cambios: { tiempoEstandarSeg?: number; titulo?: string; objetivoAprendizaje?: string }) =>
    request<{ conjunto: ConjuntoAdmin }>(`/admin/conjuntos/${id}`, { method: 'PATCH', body: cambios }),

  // CU08 — banco de preguntas (administrador)
  resumenBanco: () => request<{ ejes: ResumenEjeBanco[] }>('/admin/preguntas/resumen'),
  preguntasDeEje: (ejeCodigo: string) =>
    request<{ preguntas: PreguntaBanco[] }>(`/admin/preguntas?eje=${encodeURIComponent(ejeCodigo)}`),
  editarPregunta: (id: number, cambios: Partial<PreguntaEntrada & Pick<PreguntaBanco, 'activa' | 'revisadaPedagogicamente'>>) =>
    request<{ pregunta: PreguntaBanco }>(`/admin/preguntas/${id}`, { method: 'PATCH', body: cambios }),
  crearPregunta: (p: PreguntaEntrada) => request<{ pregunta: PreguntaBanco }>('/admin/preguntas', { method: 'POST', body: p }),
  tiposError: () => request<{ tiposError: TipoError[] }>('/admin/tipos-error'),
};

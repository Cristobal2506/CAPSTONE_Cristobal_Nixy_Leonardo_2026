// CU10 — Mi camino: la progresión lineal Kumon (reemplaza al mapa de islas tras la 2.ª revisión del cliente).
// Niveles en orden; dentro de cada nivel, los conjuntos de hojas: dominados ✔, el actual ▶ y los siguientes 🔒.
import { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, ScrollView, StyleSheet, Text, View } from 'react-native';
import { api, Camino, ConjuntoCamino } from '../api';
import { emojiAvatar } from '../avatares';
import { BotonGrande } from '../components/BotonGrande';
import { Mensaje } from '../components/Mensaje';
import { mmss } from '../tiempo';
import { colors, sizes } from '../theme';

interface Props {
  apodo: string;
  avatar?: string;
  onHacerTanda: () => void;
  onSalir: () => void;
}

export function MiCamino({ apodo, avatar, onHacerTanda, onSalir }: Props) {
  const [camino, setCamino] = useState<Camino | null>(null);
  const [error, setError] = useState(false);

  const cargar = useCallback(() => {
    setError(false);
    api.camino().then(setCamino).catch(() => setError(true));
  }, []);
  useEffect(cargar, [cargar]);

  const actual = camino?.niveles.flatMap((n) => n.conjuntos).find((c) => c.estado === 'actual');

  return (
    <View style={styles.contenedor}>
      <View style={styles.cabecera}>
        <Text style={styles.avatar} accessibilityLabel="Tu avatar">{emojiAvatar(avatar ?? 'condor')}</Text>
        <View style={{ flex: 1 }}>
          <Text style={styles.saludo}>¡Hola, {apodo}!</Text>
          <Text style={styles.sub}>Este es tu camino</Text>
        </View>
      </View>

      {error ? (
        <>
          <Mensaje tipo="error" texto="No pudimos cargar tu camino. Revisa internet." />
          <BotonGrande titulo="Intentar de nuevo" onPress={cargar} />
        </>
      ) : null}
      {!camino && !error ? <ActivityIndicator size="large" color={colors.cordillera} /> : null}

      {camino ? (
        <>
          <ScrollView style={{ flex: 1 }} contentContainerStyle={{ paddingBottom: 12 }}>
            {camino.cierreNivelPendiente ? (
              <Mensaje tipo="exito" texto="¡Terminaste un nivel completo! Tu profesor lo revisará contigo antes de seguir." />
            ) : null}
            {camino.requiereProfesor && !camino.cierreNivelPendiente ? (
              <Mensaje tipo="info" texto="Este conjunto te está costando un poco. Pronto lo practicarás con tu profesor." />
            ) : null}
            {camino.niveles.map((n) => (
              <View key={n.id} style={[styles.nivel, n.estado === 'bloqueado' && styles.nivelBloqueado]}>
                <Text style={styles.nivelNombre} accessibilityRole="header">
                  {n.estado === 'dominado' ? '✔ ' : n.estado === 'bloqueado' ? '🔒 ' : ''}{n.nombre}
                </Text>
                {n.conjuntos.map((c, i) => <Paso key={c.id} conjunto={c} ultimo={i === n.conjuntos.length - 1} />)}
              </View>
            ))}
          </ScrollView>
          {actual && !camino.cierreNivelPendiente ? (
            <BotonGrande
              titulo={camino.tandaAbiertaId ? 'Seguir con mi tanda' : 'Hacer la tanda de hoy'}
              onPress={onHacerTanda}
            />
          ) : null}
        </>
      ) : null}
      <BotonGrande titulo="Salir" onPress={onSalir} color={colors.blanco} />
    </View>
  );
}

function Paso({ conjunto: c, ultimo }: { conjunto: ConjuntoCamino; ultimo: boolean }) {
  const icono = c.estado === 'dominado' ? '✔' : c.estado === 'actual' ? '▶' : '🔒';
  const detalle = c.estado === 'dominado'
    ? `Dominado${c.mejorTiempoSeg ? ` · mejor tiempo ${mmss(c.mejorTiempoSeg)}` : ''}`
    : c.estado === 'actual'
      ? c.intentos ? `Vas en el intento ${c.intentos + 1} · meta: todo bien en ${mmss(c.tiempoEstandarSeg)}`
        : `Meta: todo bien en ${mmss(c.tiempoEstandarSeg)}`
      : 'Se abre cuando domines el anterior';
  return (
    <View style={styles.paso} accessible accessibilityLabel={`${c.titulo}. ${detalle}`}>
      <View style={styles.columnaIcono}>
        <Text style={[styles.icono, styles[c.estado]]}>{icono}</Text>
        {!ultimo ? <View style={styles.linea} /> : null}
      </View>
      <View style={[styles.tarjeta, c.estado === 'actual' && styles.tarjetaActual]}>
        <Text style={[styles.titulo, c.estado === 'bloqueado' && styles.textoBloqueado]}>{c.titulo}</Text>
        <Text style={styles.detalle}>{detalle}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  contenedor: { flex: 1, padding: 24, paddingTop: 56, backgroundColor: colors.cielo },
  cabecera: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 8 },
  avatar: { fontSize: 52 },
  saludo: { fontSize: sizes.titulo, fontWeight: '800', color: colors.cordillera },
  sub: { fontSize: sizes.texto - 2, color: colors.textoSuave },
  nivel: { marginTop: 12 },
  nivelBloqueado: { opacity: 0.6 },
  nivelNombre: { fontSize: 20, fontWeight: '800', color: colors.cordillera, marginBottom: 8 },
  paso: { flexDirection: 'row', alignItems: 'stretch' },
  columnaIcono: { width: 44, alignItems: 'center' },
  icono: {
    width: 36, height: 36, borderRadius: 18, textAlign: 'center', lineHeight: 36, fontSize: 18,
    fontWeight: '800', overflow: 'hidden',
  },
  dominado: { backgroundColor: colors.pasto, color: colors.blanco },
  actual: { backgroundColor: colors.sol, color: colors.texto },
  bloqueado: { backgroundColor: colors.blanco, color: colors.textoSuave },
  linea: { width: 4, flex: 1, backgroundColor: colors.blanco, marginVertical: 2 },
  tarjeta: { flex: 1, backgroundColor: colors.blanco, borderRadius: sizes.radio, padding: 14, marginBottom: 10 },
  tarjetaActual: { borderWidth: 3, borderColor: colors.sol },
  titulo: { fontSize: 18, fontWeight: '700', color: colors.texto },
  textoBloqueado: { color: colors.textoSuave },
  detalle: { fontSize: 15, color: colors.textoSuave, marginTop: 4 },
});

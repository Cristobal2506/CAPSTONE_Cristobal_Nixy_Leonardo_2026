const request = require('supertest');
const { createApp } = require('../src/app');

const app = createApp();
const api = () => request(app);
let n = 0;
const emailUnico = (prefijo = 'user') => `${prefijo}.${Date.now()}.${n++}@test.cl`;

async function crearAdulto(rol = 'apoderado') {
  const email = emailUnico(rol);
  const res = await api().post('/api/auth/registro').send({ email, password: 'claveSegura1', nombre: `Test ${rol}`, rol });
  return { token: res.body.token, usuario: res.body.usuario, email };
}

const auth = (token) => ({ Authorization: `Bearer ${token}` });

/** El admin no se registra por la API: se inserta directo en la base, como hace `npm run db:demo`. */
async function crearAdmin() {
  const bcrypt = require('bcryptjs');
  const { pool } = require('../src/db');
  const email = emailUnico('admin');
  await pool.query("INSERT INTO usuario (email, password_hash, nombre, rol) VALUES ($1, $2, 'Admin', 'admin')",
    [email, await bcrypt.hash('claveSegura1', 4)]);
  const res = await api().post('/api/auth/login').send({ email, password: 'claveSegura1' });
  return { token: res.body.token, email };
}

/** Apoderado con consentimiento + estudiante con sesión iniciada. */
async function crearEstudianteConSesion({ consentimiento = true } = {}) {
  const apo = await crearAdulto();
  await api().post('/api/apoderado/consentimiento').set(auth(apo.token)).send({ acepta: true });
  const est = await api().post('/api/apoderado/estudiantes').set(auth(apo.token)).send({ apodo: 'Nico', pin: '2468' });
  if (!consentimiento) await api().delete('/api/apoderado/consentimiento').set(auth(apo.token));
  const login = await api().post('/api/auth/login-estudiante')
    .send({ codigo: est.body.estudiante.codigo_acceso, pin: '2468' });
  return { apo, token: login.body.token, id: est.body.estudiante.id };
}

module.exports = { api, crearAdulto, crearAdmin, crearEstudianteConSesion, auth, emailUnico };
